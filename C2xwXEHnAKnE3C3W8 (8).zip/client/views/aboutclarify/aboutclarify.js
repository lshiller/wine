Template.Aboutclarify.rendered = function() {
	
};

Template.Aboutclarify.events({
	
});

Template.Aboutclarify.helpers({
	
});
