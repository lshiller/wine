Meteor.publish("varietal", function(varietalId) {
	return Varietal.find({_id:varietalId}, {});
});

Meteor.publish("varietals", function() {
	return Varietal.find({}, {});
});

Meteor.publish("varietals_empty", function() {
	return Varietal.find({_id:null}, {});
});

