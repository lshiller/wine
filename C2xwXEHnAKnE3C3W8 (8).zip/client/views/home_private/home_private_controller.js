this.HomePrivateController = RouteController.extend({
	template: "HomePrivate",
	

	yieldTemplates: {
		/*YIELD_TEMPLATES*/
	},

	onBeforeAction: function() {
		this.next();
	},

	action: function() {
		if(this.isReady()) { this.render(); } else { this.render("loading"); }
		/*ACTION_FUNCTION*/
	},

	isReady: function() {
		

		var subs = [
			Meteor.subscribe("barrels"),
			Meteor.subscribe("blends"),
			Meteor.subscribe("chemicals"),
			Meteor.subscribe("trxchemicalconainers"),
			Meteor.subscribe("chemicalmanufacturers"),
			Meteor.subscribe("picklocations"),
			Meteor.subscribe("picknumbers"),
			Meteor.subscribe("presss"),
			Meteor.subscribe("tanks"),
			Meteor.subscribe("tests"),
			Meteor.subscribe("units"),
			Meteor.subscribe("vintages"),
			Meteor.subscribe("varietals")
		];
		var ready = true;
		_.each(subs, function(sub) {
			if(!sub.ready())
				ready = false;
		});
		return ready;
	},

	data: function() {
		

		var data = {
			params: this.params || {},
			barrels: Barrel.find({}, {}),
			blends: Blend.find({}, {}),
			chemicals: Chemical.find({}, {}),
			trxchemicalconainers: TrxChemicalContainer.find({}, {}),
			chemicalmanufacturers: ChemicalManufacturer.find({}, {}),
			picklocations: PickLocation.find({}, {}),
			picknumbers: PickNumber.find({}, {}),
			presss: Press.find({}, {}),
			tanks: Tank.find({}, {}),
			tests: Test.find({}, {}),
			units: Unit.find({}, {}),
			vintages: Vintage.find({}, {}),
			varietals: Varietal.find({}, {})
		};
		

		

		return data;
	},

	onAfterAction: function() {
		
	}
});