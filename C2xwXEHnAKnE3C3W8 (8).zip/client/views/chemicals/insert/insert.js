var pageSession = new ReactiveDict();

Template.ChemicalsInsert.rendered = function() {
	
};

Template.ChemicalsInsert.events({
	
});

Template.ChemicalsInsert.helpers({
	
});

Template.ChemicalsInsertInsertForm.rendered = function() {
	

	pageSession.set("chemicalsInsertInsertFormInfoMessage", "");
	pageSession.set("chemicalsInsertInsertFormErrorMessage", "");

	$(".input-group.date").each(function() {
		var format = $(this).find("input[type='text']").attr("data-format");

		if(format) {
			format = format.toLowerCase();
		}
		else {
			format = "mm/dd/yyyy";
		}

		$(this).datepicker({
			autoclose: true,
			todayHighlight: true,
			todayBtn: true,
			forceParse: false,
			keyboardNavigation: false,
			format: format
		});
	});

	$("input[type='file']").fileinput();
	$("select[data-role='tagsinput']").tagsinput();
	$(".bootstrap-tagsinput").addClass("form-control");
	$("input[autofocus]").focus();
};

Template.ChemicalsInsertInsertForm.events({
	"submit": function(e, t) {
		e.preventDefault();
		pageSession.set("chemicalsInsertInsertFormInfoMessage", "");
		pageSession.set("chemicalsInsertInsertFormErrorMessage", "");

		var self = this;

		function submitAction(msg) {
			var chemicalsInsertInsertFormMode = "insert";
			if(!t.find("#form-cancel-button")) {
				switch(chemicalsInsertInsertFormMode) {
					case "insert": {
						$(e.target)[0].reset();
					}; break;

					case "update": {
						var message = msg || "Saved.";
						pageSession.set("chemicalsInsertInsertFormInfoMessage", message);
					}; break;
				}
			}

			Router.go("chemicals", {});
		}

		function errorAction(msg) {
			msg = msg || "";
			var message = msg.message || msg || "Error.";
			pageSession.set("chemicalsInsertInsertFormErrorMessage", message);
		}

		validateForm(
			$(e.target),
			function(fieldName, fieldValue) {

			},
			function(msg) {

			},
			function(values) {
				

				newId = Chemical.insert(values, function(e) { if(e) errorAction(e); else submitAction(); });
			}
		);

		return false;
	},
	"click #form-cancel-button": function(e, t) {
		e.preventDefault();

		

		Router.go("chemicals", {});
	},
	"click #form-close-button": function(e, t) {
		e.preventDefault();

		/*CLOSE_REDIRECT*/
	},
	"click #form-back-button": function(e, t) {
		e.preventDefault();

		/*BACK_REDIRECT*/
	}

	
});

Template.ChemicalsInsertInsertForm.helpers({
	"infoMessage": function() {
		return pageSession.get("chemicalsInsertInsertFormInfoMessage");
	},
	"errorMessage": function() {
		return pageSession.get("chemicalsInsertInsertFormErrorMessage");
	}
	
});
