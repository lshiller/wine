Meteor.publish("blend", function(blendId) {
	return Blend.find({_id:blendId}, {});
});

Meteor.publish("blends", function() {
	return Blend.find({}, {});
});

Meteor.publish("blends_empty", function() {
	return Blend.find({_id:null}, {});
});

