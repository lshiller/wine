Meteor.publish("barrel", function(barrelId) {
	return Barrel.find({_id:barrelId}, {});
});

Meteor.publish("barrels", function() {
	return Barrel.find({}, {});
});

Meteor.publish("barrels_empty", function() {
	return Barrel.find({_id:null}, {});
});

