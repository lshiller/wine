this.TrxChemicalContainer = new Mongo.Collection("TrxChemicalContainer");

this.TrxChemicalContainer.userCanInsert = function(userId, doc) {
	return true;
};

this.TrxChemicalContainer.userCanUpdate = function(userId, doc) {
	return true;
};

this.TrxChemicalContainer.userCanRemove = function(userId, doc) {
	return true;
};
