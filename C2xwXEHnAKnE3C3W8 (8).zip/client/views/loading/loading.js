Template.loading.rendered = function() {
	/*TEMPLATE_RENDERED_CODE*/
};

Template.loading.events({

});

Template.loading.helpers({

});
