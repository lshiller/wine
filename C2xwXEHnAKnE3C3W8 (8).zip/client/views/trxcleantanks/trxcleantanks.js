var pageSession = new ReactiveDict();

Template.Trxcleantanks.rendered = function() {
	
};

Template.Trxcleantanks.events({
	
});

Template.Trxcleantanks.helpers({
	
});

var TrxcleantanksViewItems = function(cursor) {
	if(!cursor) {
		return [];
	}

	var searchString = pageSession.get("TrxcleantanksViewSearchString");
	var sortBy = pageSession.get("TrxcleantanksViewSortBy");
	var sortAscending = pageSession.get("TrxcleantanksViewSortAscending");
	if(typeof(sortAscending) == "undefined") sortAscending = true;

	var raw = cursor.fetch();

	// filter
	var filtered = [];
	if(!searchString || searchString == "") {
		filtered = raw;
	} else {
		searchString = searchString.replace(".", "\\.");
		var regEx = new RegExp(searchString, "i");
		var searchFields = ["Tank", "CleaningDatetime"];
		filtered = _.filter(raw, function(item) {
			var match = false;
			_.each(searchFields, function(field) {
				var value = (getPropertyValue(field, item) || "") + "";

				match = match || (value && value.match(regEx));
				if(match) {
					return false;
				}
			})
			return match;
		});
	}

	// sort
	if(sortBy) {
		filtered = _.sortBy(filtered, sortBy);

		// descending?
		if(!sortAscending) {
			filtered = filtered.reverse();
		}
	}

	return filtered;
};

var TrxcleantanksViewExport = function(cursor, fileType) {
	var data = TrxcleantanksViewItems(cursor);
	var exportFields = [];

	var str = convertArrayOfObjects(data, exportFields, fileType);

	var filename = "export." + fileType;

	downloadLocalResource(str, filename, "application/octet-stream");
}


Template.TrxcleantanksView.rendered = function() {
	pageSession.set("TrxcleantanksViewStyle", "table");
	
};

Template.TrxcleantanksView.events({
	"submit #dataview-controls": function(e, t) {
		return false;
	},

	"click #dataview-search-button": function(e, t) {
		e.preventDefault();
		var form = $(e.currentTarget).parent();
		if(form) {
			var searchInput = form.find("#dataview-search-input");
			if(searchInput) {
				searchInput.focus();
				var searchString = searchInput.val();
				pageSession.set("TrxcleantanksViewSearchString", searchString);
			}

		}
		return false;
	},

	"keydown #dataview-search-input": function(e, t) {
		if(e.which === 13)
		{
			e.preventDefault();
			var form = $(e.currentTarget).parent();
			if(form) {
				var searchInput = form.find("#dataview-search-input");
				if(searchInput) {
					var searchString = searchInput.val();
					pageSession.set("TrxcleantanksViewSearchString", searchString);
				}

			}
			return false;
		}

		if(e.which === 27)
		{
			e.preventDefault();
			var form = $(e.currentTarget).parent();
			if(form) {
				var searchInput = form.find("#dataview-search-input");
				if(searchInput) {
					searchInput.val("");
					pageSession.set("TrxcleantanksViewSearchString", "");
				}

			}
			return false;
		}

		return true;
	},

	"click #dataview-insert-button": function(e, t) {
		e.preventDefault();
		Router.go("trxcleantanks.insert", {});
	},

	"click #dataview-export-default": function(e, t) {
		e.preventDefault();
		TrxcleantanksViewExport(this.trxcleantanks, "csv");
	},

	"click #dataview-export-csv": function(e, t) {
		e.preventDefault();
		TrxcleantanksViewExport(this.trxcleantanks, "csv");
	},

	"click #dataview-export-tsv": function(e, t) {
		e.preventDefault();
		TrxcleantanksViewExport(this.trxcleantanks, "tsv");
	},

	"click #dataview-export-json": function(e, t) {
		e.preventDefault();
		TrxcleantanksViewExport(this.trxcleantanks, "json");
	}

	
});

Template.TrxcleantanksView.helpers({

	"insertButtonClass": function() {
		return TrxCleanTank.userCanInsert(Meteor.userId(), {}) ? "" : "hidden";
	},

	"isEmpty": function() {
		return !this.trxcleantanks || this.trxcleantanks.count() == 0;
	},
	"isNotEmpty": function() {
		return this.trxcleantanks && this.trxcleantanks.count() > 0;
	},
	"isNotFound": function() {
		return this.trxcleantanks && pageSession.get("TrxcleantanksViewSearchString") && TrxcleantanksViewItems(this.trxcleantanks).length == 0;
	},
	"searchString": function() {
		return pageSession.get("TrxcleantanksViewSearchString");
	},
	"viewAsTable": function() {
		return pageSession.get("TrxcleantanksViewStyle") == "table";
	},
	"viewAsList": function() {
		return pageSession.get("TrxcleantanksViewStyle") == "list";
	},
	"viewAsGallery": function() {
		return pageSession.get("TrxcleantanksViewStyle") == "gallery";
	}

	
});


Template.TrxcleantanksViewTable.rendered = function() {
	
};

Template.TrxcleantanksViewTable.events({
	"click .th-sortable": function(e, t) {
		e.preventDefault();
		var oldSortBy = pageSession.get("TrxcleantanksViewSortBy");
		var newSortBy = $(e.target).attr("data-sort");

		pageSession.set("TrxcleantanksViewSortBy", newSortBy);
		if(oldSortBy == newSortBy) {
			var sortAscending = pageSession.get("TrxcleantanksViewSortAscending") || false;
			pageSession.set("TrxcleantanksViewSortAscending", !sortAscending);
		} else {
			pageSession.set("TrxcleantanksViewSortAscending", true);
		}
	}
});

Template.TrxcleantanksViewTable.helpers({
	"tableItems": function() {
		return TrxcleantanksViewItems(this.trxcleantanks);
	}
});


Template.TrxcleantanksViewTableItems.rendered = function() {
	
};

Template.TrxcleantanksViewTableItems.events({
	"click td": function(e, t) {
		e.preventDefault();
		
		Router.go("trxcleantanks.details", {trxcleantankId: this._id});
		return false;
	},

	"click .inline-checkbox": function(e, t) {
		e.preventDefault();

		if(!this || !this._id) return false;

		var fieldName = $(e.currentTarget).attr("data-field");
		if(!fieldName) return false;

		var values = {};
		values[fieldName] = !this[fieldName];

		TrxCleanTank.update({ _id: this._id }, { $set: values });

		return false;
	},

	"click #delete-button": function(e, t) {
		e.preventDefault();
		var me = this;
		bootbox.dialog({
			message: "Delete? Are you sure?",
			title: "Delete",
			animate: false,
			buttons: {
				success: {
					label: "Yes",
					className: "btn-success",
					callback: function() {
						TrxCleanTank.remove({ _id: me._id });
					}
				},
				danger: {
					label: "No",
					className: "btn-default"
				}
			}
		});
		return false;
	},
	"click #edit-button": function(e, t) {
		e.preventDefault();
		Router.go("trxcleantanks.edit", {trxcleantankId: this._id});
		return false;
	}
});

Template.TrxcleantanksViewTableItems.helpers({
	"checked": function(value) { return value ? "checked" : "" }, 
	"editButtonClass": function() {
		return TrxCleanTank.userCanUpdate(Meteor.userId(), this) ? "" : "hidden";
	},

	"deleteButtonClass": function() {
		return TrxCleanTank.userCanRemove(Meteor.userId(), this) ? "" : "hidden";
	}
});
