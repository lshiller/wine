this.Press = new Mongo.Collection("Press");

this.Press.userCanInsert = function(userId, doc) {
	return true;
};

this.Press.userCanUpdate = function(userId, doc) {
	return true;
};

this.Press.userCanRemove = function(userId, doc) {
	return true;
};
