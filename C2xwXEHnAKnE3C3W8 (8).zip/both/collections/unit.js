this.Unit = new Mongo.Collection("Unit");

this.Unit.userCanInsert = function(userId, doc) {
	return true;
};

this.Unit.userCanUpdate = function(userId, doc) {
	return true;
};

this.Unit.userCanRemove = function(userId, doc) {
	return true;
};
