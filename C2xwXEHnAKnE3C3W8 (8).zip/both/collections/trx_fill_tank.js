this.TrxFillTank = new Mongo.Collection("TrxFillTank");

this.TrxFillTank.userCanInsert = function(userId, doc) {
	return true;
};

this.TrxFillTank.userCanUpdate = function(userId, doc) {
	return true;
};

this.TrxFillTank.userCanRemove = function(userId, doc) {
	return true;
};
