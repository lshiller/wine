Meteor.publish("vintage", function(vintageId) {
	return Vintage.find({_id:vintageId}, {});
});

Meteor.publish("vintages", function() {
	return Vintage.find({}, {});
});

Meteor.publish("vintages_empty", function() {
	return Vintage.find({_id:null}, {});
});

