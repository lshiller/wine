Meteor.publish("trxlottoblend", function(trxlottoblendId) {
	return TrxLotToBlend.find({_id:trxlottoblendId}, {});
});

Meteor.publish("trxlottoblends", function() {
	return TrxLotToBlend.find({}, {});
});

Meteor.publish("trxlottoblends_empty", function() {
	return TrxLotToBlend.find({_id:null}, {});
});

