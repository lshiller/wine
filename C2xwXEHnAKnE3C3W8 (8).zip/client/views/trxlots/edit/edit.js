var pageSession = new ReactiveDict();

Template.TrxlotsEdit.rendered = function() {
	
};

Template.TrxlotsEdit.events({
	
});

Template.TrxlotsEdit.helpers({
	
});

Template.TrxlotsEditEditForm.rendered = function() {
	

	pageSession.set("trxlotsEditEditFormInfoMessage", "");
	pageSession.set("trxlotsEditEditFormErrorMessage", "");

	$(".input-group.date").each(function() {
		var format = $(this).find("input[type='text']").attr("data-format");

		if(format) {
			format = format.toLowerCase();
		}
		else {
			format = "mm/dd/yyyy";
		}

		$(this).datepicker({
			autoclose: true,
			todayHighlight: true,
			todayBtn: true,
			forceParse: false,
			keyboardNavigation: false,
			format: format
		});
	});

	$("input[type='file']").fileinput();
	$("select[data-role='tagsinput']").tagsinput();
	$(".bootstrap-tagsinput").addClass("form-control");
	$("input[autofocus]").focus();
};

Template.TrxlotsEditEditForm.events({
	"submit": function(e, t) {
		e.preventDefault();
		pageSession.set("trxlotsEditEditFormInfoMessage", "");
		pageSession.set("trxlotsEditEditFormErrorMessage", "");

		var self = this;

		function submitAction(msg) {
			var trxlotsEditEditFormMode = "update";
			if(!t.find("#form-cancel-button")) {
				switch(trxlotsEditEditFormMode) {
					case "insert": {
						$(e.target)[0].reset();
					}; break;

					case "update": {
						var message = msg || "Saved.";
						pageSession.set("trxlotsEditEditFormInfoMessage", message);
					}; break;
				}
			}

			Router.go("trxlots", {});
		}

		function errorAction(msg) {
			msg = msg || "";
			var message = msg.message || msg || "Error.";
			pageSession.set("trxlotsEditEditFormErrorMessage", message);
		}

		validateForm(
			$(e.target),
			function(fieldName, fieldValue) {

			},
			function(msg) {

			},
			function(values) {
				

				TrxLot.update({ _id: t.data.trxlot._id }, { $set: values }, function(e) { if(e) errorAction(e); else submitAction(); });
			}
		);

		return false;
	},
	"click #form-cancel-button": function(e, t) {
		e.preventDefault();

		

		Router.go("trxlots", {});
	},
	"click #form-close-button": function(e, t) {
		e.preventDefault();

		/*CLOSE_REDIRECT*/
	},
	"click #form-back-button": function(e, t) {
		e.preventDefault();

		/*BACK_REDIRECT*/
	}

	
});

Template.TrxlotsEditEditForm.helpers({
	"infoMessage": function() {
		return pageSession.get("trxlotsEditEditFormInfoMessage");
	},
	"errorMessage": function() {
		return pageSession.get("trxlotsEditEditFormErrorMessage");
	}
	
});
