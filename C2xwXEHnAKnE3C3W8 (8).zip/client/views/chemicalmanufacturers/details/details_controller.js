this.ChemicalmanufacturersDetailsController = RouteController.extend({
	template: "ChemicalmanufacturersDetails",
	

	yieldTemplates: {
		/*YIELD_TEMPLATES*/
	},

	onBeforeAction: function() {
		this.next();
	},

	action: function() {
		if(this.isReady()) { this.render(); } else { this.render("loading"); }
		/*ACTION_FUNCTION*/
	},

	isReady: function() {
		

		var subs = [
			Meteor.subscribe("chemicalmanufacturer", this.params.chemicalmanufacturerId)
		];
		var ready = true;
		_.each(subs, function(sub) {
			if(!sub.ready())
				ready = false;
		});
		return ready;
	},

	data: function() {
		

		var data = {
			params: this.params || {},
			chemicalmanufacturer: ChemicalManufacturer.findOne({_id:this.params.chemicalmanufacturerId}, {})
		};
		

		

		return data;
	},

	onAfterAction: function() {
		
	}
});