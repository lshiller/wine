Unit.allow({
	insert: function (userId, doc) {
		return Unit.userCanInsert(userId, doc);
	},

	update: function (userId, doc, fields, modifier) {
		return Unit.userCanUpdate(userId, doc);
	},

	remove: function (userId, doc) {
		return Unit.userCanRemove(userId, doc);
	}
});

Unit.before.insert(function(userId, doc) {
	doc.createdAt = new Date();
	doc.createdBy = userId;
	doc.modifiedAt = doc.createdAt;
	doc.modifiedBy = doc.createdBy;

	
	if(!doc.createdBy) doc.createdBy = userId;
});

Unit.before.update(function(userId, doc, fieldNames, modifier, options) {
	modifier.$set = modifier.$set || {};
	modifier.$set.modifiedAt = new Date();
	modifier.$set.modifiedBy = userId;

	
});

Unit.before.upsert(function(userId, selector, modifier, options) {
	modifier.$set = modifier.$set || {};
	modifier.$set.modifiedAt = new Date();
	modifier.$set.modifiedBy = userId;

	/*BEFORE_UPSERT_CODE*/
});

Unit.before.remove(function(userId, doc) {
	
});

Unit.after.insert(function(userId, doc) {
	
});

Unit.after.update(function(userId, doc, fieldNames, modifier, options) {
	
});

Unit.after.remove(function(userId, doc) {
	
});
