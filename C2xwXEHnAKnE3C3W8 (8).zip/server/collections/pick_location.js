PickLocation.allow({
	insert: function (userId, doc) {
		return PickLocation.userCanInsert(userId, doc);
	},

	update: function (userId, doc, fields, modifier) {
		return PickLocation.userCanUpdate(userId, doc);
	},

	remove: function (userId, doc) {
		return PickLocation.userCanRemove(userId, doc);
	}
});

PickLocation.before.insert(function(userId, doc) {
	doc.createdAt = new Date();
	doc.createdBy = userId;
	doc.modifiedAt = doc.createdAt;
	doc.modifiedBy = doc.createdBy;

	
	if(!doc.createdBy) doc.createdBy = userId;
});

PickLocation.before.update(function(userId, doc, fieldNames, modifier, options) {
	modifier.$set = modifier.$set || {};
	modifier.$set.modifiedAt = new Date();
	modifier.$set.modifiedBy = userId;

	
});

PickLocation.before.upsert(function(userId, selector, modifier, options) {
	modifier.$set = modifier.$set || {};
	modifier.$set.modifiedAt = new Date();
	modifier.$set.modifiedBy = userId;

	/*BEFORE_UPSERT_CODE*/
});

PickLocation.before.remove(function(userId, doc) {
	
});

PickLocation.after.insert(function(userId, doc) {
	
});

PickLocation.after.update(function(userId, doc, fieldNames, modifier, options) {
	
});

PickLocation.after.remove(function(userId, doc) {
	
});
