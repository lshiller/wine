this.TrxfilltanksDetailsController = RouteController.extend({
	template: "TrxfilltanksDetails",
	

	yieldTemplates: {
		/*YIELD_TEMPLATES*/
	},

	onBeforeAction: function() {
		this.next();
	},

	action: function() {
		if(this.isReady()) { this.render(); } else { this.render("loading"); }
		/*ACTION_FUNCTION*/
	},

	isReady: function() {
		

		var subs = [
			Meteor.subscribe("trxfilltank", this.params.trxfilltankId)
		];
		var ready = true;
		_.each(subs, function(sub) {
			if(!sub.ready())
				ready = false;
		});
		return ready;
	},

	data: function() {
		

		var data = {
			params: this.params || {},
			trxfilltank: TrxFillTank.findOne({_id:this.params.trxfilltankId}, {})
		};
		

		

		return data;
	},

	onAfterAction: function() {
		
	}
});