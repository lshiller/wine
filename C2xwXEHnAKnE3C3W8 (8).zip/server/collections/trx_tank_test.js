TrxTankTest.allow({
	insert: function (userId, doc) {
		return TrxTankTest.userCanInsert(userId, doc);
	},

	update: function (userId, doc, fields, modifier) {
		return TrxTankTest.userCanUpdate(userId, doc);
	},

	remove: function (userId, doc) {
		return TrxTankTest.userCanRemove(userId, doc);
	}
});

TrxTankTest.before.insert(function(userId, doc) {
	doc.createdAt = new Date();
	doc.createdBy = userId;
	doc.modifiedAt = doc.createdAt;
	doc.modifiedBy = doc.createdBy;

	
	if(!doc.createdBy) doc.createdBy = userId;
});

TrxTankTest.before.update(function(userId, doc, fieldNames, modifier, options) {
	modifier.$set = modifier.$set || {};
	modifier.$set.modifiedAt = new Date();
	modifier.$set.modifiedBy = userId;

	
});

TrxTankTest.before.upsert(function(userId, selector, modifier, options) {
	modifier.$set = modifier.$set || {};
	modifier.$set.modifiedAt = new Date();
	modifier.$set.modifiedBy = userId;

	/*BEFORE_UPSERT_CODE*/
});

TrxTankTest.before.remove(function(userId, doc) {
	
});

TrxTankTest.after.insert(function(userId, doc) {
	
});

TrxTankTest.after.update(function(userId, doc, fieldNames, modifier, options) {
	
});

TrxTankTest.after.remove(function(userId, doc) {
	
});
