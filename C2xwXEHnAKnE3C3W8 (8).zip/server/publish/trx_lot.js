Meteor.publish("trxlot", function(trxlotId) {
	return TrxLot.find({_id:trxlotId}, {});
});

Meteor.publish("trxlots", function() {
	return TrxLot.find({}, {});
});

Meteor.publish("trxlots_empty", function() {
	return TrxLot.find({_id:null}, {});
});

