this.TrxLotToBlend = new Mongo.Collection("TrxLotToBlend");

this.TrxLotToBlend.userCanInsert = function(userId, doc) {
	return true;
};

this.TrxLotToBlend.userCanUpdate = function(userId, doc) {
	return true;
};

this.TrxLotToBlend.userCanRemove = function(userId, doc) {
	return true;
};
