this.TrxaddchemicaltotanksEditController = RouteController.extend({
	template: "TrxaddchemicaltotanksEdit",
	

	yieldTemplates: {
		/*YIELD_TEMPLATES*/
	},

	onBeforeAction: function() {
		this.next();
	},

	action: function() {
		if(this.isReady()) { this.render(); } else { this.render("loading"); }
		/*ACTION_FUNCTION*/
	},

	isReady: function() {
		

		var subs = [
			Meteor.subscribe("tanks"),
			Meteor.subscribe("chemicals"),
			Meteor.subscribe("trxaddchemicaltotank", this.params.trxaddchemicaltotankId)
		];
		var ready = true;
		_.each(subs, function(sub) {
			if(!sub.ready())
				ready = false;
		});
		return ready;
	},

	data: function() {
		

		var data = {
			params: this.params || {},
			tanks: Tank.find({}, {}),
			chemicals: Chemical.find({}, {}),
			trxaddchemicaltotank: TrxAddChemicalToTank.findOne({_id:this.params.trxaddchemicaltotankId}, {})
		};
		

		

		return data;
	},

	onAfterAction: function() {
		
	}
});