this.Varietal = new Mongo.Collection("Varietal");

this.Varietal.userCanInsert = function(userId, doc) {
	return true;
};

this.Varietal.userCanUpdate = function(userId, doc) {
	return true;
};

this.Varietal.userCanRemove = function(userId, doc) {
	return true;
};
