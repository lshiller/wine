this.Vintage = new Mongo.Collection("Vintage");

this.Vintage.userCanInsert = function(userId, doc) {
	return true;
};

this.Vintage.userCanUpdate = function(userId, doc) {
	return true;
};

this.Vintage.userCanRemove = function(userId, doc) {
	return true;
};
