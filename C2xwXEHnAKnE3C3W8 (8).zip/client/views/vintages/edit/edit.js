var pageSession = new ReactiveDict();

Template.VintagesEdit.rendered = function() {
	
};

Template.VintagesEdit.events({
	
});

Template.VintagesEdit.helpers({
	
});

Template.VintagesEditEditForm.rendered = function() {
	

	pageSession.set("vintagesEditEditFormInfoMessage", "");
	pageSession.set("vintagesEditEditFormErrorMessage", "");

	$(".input-group.date").each(function() {
		var format = $(this).find("input[type='text']").attr("data-format");

		if(format) {
			format = format.toLowerCase();
		}
		else {
			format = "mm/dd/yyyy";
		}

		$(this).datepicker({
			autoclose: true,
			todayHighlight: true,
			todayBtn: true,
			forceParse: false,
			keyboardNavigation: false,
			format: format
		});
	});

	$("input[type='file']").fileinput();
	$("select[data-role='tagsinput']").tagsinput();
	$(".bootstrap-tagsinput").addClass("form-control");
	$("input[autofocus]").focus();
};

Template.VintagesEditEditForm.events({
	"submit": function(e, t) {
		e.preventDefault();
		pageSession.set("vintagesEditEditFormInfoMessage", "");
		pageSession.set("vintagesEditEditFormErrorMessage", "");

		var self = this;

		function submitAction(msg) {
			var vintagesEditEditFormMode = "update";
			if(!t.find("#form-cancel-button")) {
				switch(vintagesEditEditFormMode) {
					case "insert": {
						$(e.target)[0].reset();
					}; break;

					case "update": {
						var message = msg || "Saved.";
						pageSession.set("vintagesEditEditFormInfoMessage", message);
					}; break;
				}
			}

			Router.go("vintages", {});
		}

		function errorAction(msg) {
			msg = msg || "";
			var message = msg.message || msg || "Error.";
			pageSession.set("vintagesEditEditFormErrorMessage", message);
		}

		validateForm(
			$(e.target),
			function(fieldName, fieldValue) {

			},
			function(msg) {

			},
			function(values) {
				

				Vintage.update({ _id: t.data.vintage._id }, { $set: values }, function(e) { if(e) errorAction(e); else submitAction(); });
			}
		);

		return false;
	},
	"click #form-cancel-button": function(e, t) {
		e.preventDefault();

		

		Router.go("vintages", {});
	},
	"click #form-close-button": function(e, t) {
		e.preventDefault();

		/*CLOSE_REDIRECT*/
	},
	"click #form-back-button": function(e, t) {
		e.preventDefault();

		/*BACK_REDIRECT*/
	}

	
});

Template.VintagesEditEditForm.helpers({
	"infoMessage": function() {
		return pageSession.get("vintagesEditEditFormInfoMessage");
	},
	"errorMessage": function() {
		return pageSession.get("vintagesEditEditFormErrorMessage");
	}
	
});
