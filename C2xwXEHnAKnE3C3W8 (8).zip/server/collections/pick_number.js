PickNumber.allow({
	insert: function (userId, doc) {
		return PickNumber.userCanInsert(userId, doc);
	},

	update: function (userId, doc, fields, modifier) {
		return PickNumber.userCanUpdate(userId, doc);
	},

	remove: function (userId, doc) {
		return PickNumber.userCanRemove(userId, doc);
	}
});

PickNumber.before.insert(function(userId, doc) {
	doc.createdAt = new Date();
	doc.createdBy = userId;
	doc.modifiedAt = doc.createdAt;
	doc.modifiedBy = doc.createdBy;

	
	if(!doc.createdBy) doc.createdBy = userId;
});

PickNumber.before.update(function(userId, doc, fieldNames, modifier, options) {
	modifier.$set = modifier.$set || {};
	modifier.$set.modifiedAt = new Date();
	modifier.$set.modifiedBy = userId;

	
});

PickNumber.before.upsert(function(userId, selector, modifier, options) {
	modifier.$set = modifier.$set || {};
	modifier.$set.modifiedAt = new Date();
	modifier.$set.modifiedBy = userId;

	/*BEFORE_UPSERT_CODE*/
});

PickNumber.before.remove(function(userId, doc) {
	
});

PickNumber.after.insert(function(userId, doc) {
	
});

PickNumber.after.update(function(userId, doc, fieldNames, modifier, options) {
	
});

PickNumber.after.remove(function(userId, doc) {
	
});
