Router.configure({
	templateNameConverter: "upperCamelCase",
	routeControllerNameConverter: "upperCamelCase",
	layoutTemplate: "layout",
	notFoundTemplate: "notFound",
	loadingTemplate: "loading"
});

var publicRoutes = [
	"home_public",
	"login",
	"register",
	"forgot_password",
	"reset_password"
];

var privateRoutes = [
	"home_private",
	"user_settings",
	"user_settings.profile",
	"user_settings.change_pass",
	"logout",
	"chemicals",
	"chemicals.insert",
	"chemicals.details",
	"chemicals.edit",
	"blends",
	"blends.insert",
	"blends.details",
	"blends.edit",
	"chemicalmanufacturers",
	"chemicalmanufacturers.insert",
	"chemicalmanufacturers.details",
	"chemicalmanufacturers.edit",
	"trxchemicalconainers",
	"trxchemicalconainers.insert",
	"trxchemicalconainers.details",
	"trxchemicalconainers.edit",
	"units",
	"units.insert",
	"units.details",
	"units.edit",
	"trxlots",
	"trxlots.insert",
	"trxlots.details",
	"trxlots.edit",
	"vintages",
	"vintages.insert",
	"vintages.details",
	"vintages.edit",
	"varietals",
	"varietals.insert",
	"varietals.details",
	"varietals.edit",
	"picklocations",
	"picklocations.insert",
	"picklocations.details",
	"picklocations.edit",
	"picknumbers",
	"picknumbers.insert",
	"picknumbers.details",
	"picknumbers.edit",
	"presss",
	"presss.insert",
	"presss.details",
	"presss.edit",
	"tanks",
	"tanks.insert",
	"tanks.details",
	"tanks.edit",
	"ttests",
	"ttests.insert",
	"ttests.details",
	"ttests.edit",
	"barrels",
	"barrels.insert",
	"barrels.details",
	"barrels.edit",
	"trxaddchemicaltotanks",
	"trxaddchemicaltotanks.insert",
	"trxaddchemicaltotanks.details",
	"trxaddchemicaltotanks.edit",
	"trxbarreltotanks",
	"trxbarreltotanks.insert",
	"trxbarreltotanks.details",
	"trxbarreltotanks.edit",
	"trxcleantanks",
	"trxcleantanks.insert",
	"trxcleantanks.details",
	"trxcleantanks.edit",
	"trxtankcleaningchemicals",
	"trxtankcleaningchemicals.insert",
	"trxtankcleaningchemicals.details",
	"trxtankcleaningchemicals.edit",
	"trxfilltanks",
	"trxfilltanks.insert",
	"trxfilltanks.details",
	"trxfilltanks.edit",
	"trxtanktests",
	"trxtanktests.insert",
	"trxtanktests.details",
	"trxtanktests.edit",
	"trxblendtoblends",
	"trxblendtoblends.insert",
	"trxblendtoblends.details",
	"trxblendtoblends.edit",
	"trxlottoblends",
	"trxlottoblends.insert",
	"trxlottoblends.details",
	"trxlottoblends.edit"
];

var freeRoutes = [
	"aboutclarify"
];

var roleMap = [
	
];

this.firstGrantedRoute = function(preferredRoute) {
	if(preferredRoute && routeGranted(preferredRoute)) return preferredRoute;

	var grantedRoute = "";

	_.every(privateRoutes, function(route) {
		if(routeGranted(route)) {
			grantedRoute = route;
			return false;
		}
		return true;
	});
	if(grantedRoute) return grantedRoute;

	_.every(publicRoutes, function(route) {
		if(routeGranted(route)) {
			grantedRoute = route;
			return false;
		}
		return true;
	});
	if(grantedRoute) return grantedRoute;

	_.every(freeRoutes, function(route) {
		if(routeGranted(route)) {
			grantedRoute = route;
			return false;
		}
		return true;
	});
	if(grantedRoute) return grantedRoute;

	if(!grantedRoute) {
		// what to do?
		console.log("All routes are restricted for current user.");
	}

	return "";
}

// this function returns true if user is in role allowed to access given route
this.routeGranted = function(routeName) {
	if(!routeName) {
		// route without name - enable access (?)
		return true;
	}

	if(!roleMap || roleMap.length === 0) {
		// this app don't have role map - enable access
		return true;
	}

	var roleMapItem = _.find(roleMap, function(roleItem) { return roleItem.route == routeName; });
	if(!roleMapItem) {
		// page is not restricted
		return true;
	}

	if(!Meteor.user() || !Meteor.user().roles) {
		// user is not logged in
		return false;
	}

	// this page is restricted to some role(s), check if user is in one of allowedRoles
	var allowedRoles = roleMapItem.roles;
	var granted = _.intersection(allowedRoles, Meteor.user().roles);
	if(!granted || granted.length === 0) {
		return false;
	}

	return true;
};

Router.ensureLogged = function() {
	if(Meteor.userId() && (!Meteor.user() || !Meteor.user().roles)) {
		this.render('loading');
		return;
	}

	if(!Meteor.userId()) {
		// user is not logged in - redirect to public home
		var redirectRoute = firstGrantedRoute("home_public");
		this.redirect(redirectRoute);
	} else {
		// user is logged in - check role
		if(!routeGranted(this.route.getName())) {
			// user is not in allowedRoles - redirect to first granted route
			var redirectRoute = firstGrantedRoute("home_private");
			this.redirect(redirectRoute);
		} else {
			this.next();
		}
	}
};

Router.ensureNotLogged = function() {
	if(Meteor.userId() && (!Meteor.user() || !Meteor.user().roles)) {
		this.render('loading');
		return;
	}

	if(Meteor.userId()) {
		var redirectRoute = firstGrantedRoute("home_private");
		this.redirect(redirectRoute);
	}
	else {
		this.next();
	}
};

// called for pages in free zone - some of pages can be restricted
Router.ensureGranted = function() {
	if(Meteor.userId() && (!Meteor.user() || !Meteor.user().roles)) {
		this.render('loading');
		return;
	}

	if(!routeGranted(this.route.getName())) {
		// user is not in allowedRoles - redirect to first granted route
		var redirectRoute = firstGrantedRoute("aboutclarify");
		this.redirect(redirectRoute);
	} else {
		this.next();
	}
};

Router.waitOn(function() { 
	Meteor.subscribe("current_user_data");
});

Router.onBeforeAction(function() {
	// loading indicator here
	if(!this.ready()) {
		this.render('loading');
		$("body").addClass("wait");
	} else {
		$("body").removeClass("wait");
		this.next();
	}
});

Router.onBeforeAction(Router.ensureNotLogged, {only: publicRoutes});
Router.onBeforeAction(Router.ensureLogged, {only: privateRoutes});
Router.onBeforeAction(Router.ensureGranted, {only: freeRoutes}); // yes, route from free zone can be restricted to specific set of user roles

Router.map(function () {
	
	this.route("aboutclarify", {path: "/aboutclarify", controller: "AboutclarifyController"});
	this.route("home_public", {path: "/", controller: "HomePublicController"});
	this.route("login", {path: "/login", controller: "LoginController"});
	this.route("register", {path: "/register", controller: "RegisterController"});
	this.route("forgot_password", {path: "/forgot_password", controller: "ForgotPasswordController"});
	this.route("reset_password", {path: "/reset_password/:resetPasswordToken", controller: "ResetPasswordController"});
	this.route("home_private", {path: "/home_private", controller: "HomePrivateController"});
	this.route("user_settings", {path: "/user_settings", controller: "UserSettingsController"});
	this.route("user_settings.profile", {path: "/user_settings/profile", controller: "UserSettingsProfileController"});
	this.route("user_settings.change_pass", {path: "/user_settings/change_pass", controller: "UserSettingsChangePassController"});
	this.route("logout", {path: "/logout", controller: "LogoutController"});
	this.route("chemicals", {path: "/chemicals", controller: "ChemicalsController"});
	this.route("chemicals.insert", {path: "/chemicals/insert", controller: "ChemicalsInsertController"});
	this.route("chemicals.details", {path: "/chemicals/details/:chemicalId", controller: "ChemicalsDetailsController"});
	this.route("chemicals.edit", {path: "/chemicals/edit/:chemicalId", controller: "ChemicalsEditController"});
	this.route("blends", {path: "/blends", controller: "BlendsController"});
	this.route("blends.insert", {path: "/blends/insert", controller: "BlendsInsertController"});
	this.route("blends.details", {path: "/blends/details/:blendId", controller: "BlendsDetailsController"});
	this.route("blends.edit", {path: "/blends/edit/:blendId", controller: "BlendsEditController"});
	this.route("chemicalmanufacturers", {path: "/chemicalmanufacturers", controller: "ChemicalmanufacturersController"});
	this.route("chemicalmanufacturers.insert", {path: "/chemicalmanufacturers/insert", controller: "ChemicalmanufacturersInsertController"});
	this.route("chemicalmanufacturers.details", {path: "/chemicalmanufacturers/details/:chemicalmanufacturerId", controller: "ChemicalmanufacturersDetailsController"});
	this.route("chemicalmanufacturers.edit", {path: "/chemicalmanufacturers/edit/:chemicalmanufacturerId", controller: "ChemicalmanufacturersEditController"});
	this.route("trxchemicalconainers", {path: "/trxchemicalconainers", controller: "TrxchemicalconainersController"});
	this.route("trxchemicalconainers.insert", {path: "/trxchemicalconainers/insert", controller: "TrxchemicalconainersInsertController"});
	this.route("trxchemicalconainers.details", {path: "/trxchemicalconainers/details/:trxchemicalconainerId", controller: "TrxchemicalconainersDetailsController"});
	this.route("trxchemicalconainers.edit", {path: "/trxchemicalconainers/edit/:trxchemicalconainerId", controller: "TrxchemicalconainersEditController"});
	this.route("units", {path: "/units", controller: "UnitsController"});
	this.route("units.insert", {path: "/units/insert", controller: "UnitsInsertController"});
	this.route("units.details", {path: "/units/details/:unitId", controller: "UnitsDetailsController"});
	this.route("units.edit", {path: "/units/edit/:unitId", controller: "UnitsEditController"});
	this.route("trxlots", {path: "/trxlots", controller: "TrxlotsController"});
	this.route("trxlots.insert", {path: "/trxlots/insert", controller: "TrxlotsInsertController"});
	this.route("trxlots.details", {path: "/trxlots/details/:trxlotId", controller: "TrxlotsDetailsController"});
	this.route("trxlots.edit", {path: "/trxlots/edit/:trxlotId", controller: "TrxlotsEditController"});
	this.route("vintages", {path: "/vintages", controller: "VintagesController"});
	this.route("vintages.insert", {path: "/vintages/insert", controller: "VintagesInsertController"});
	this.route("vintages.details", {path: "/vintages/details/:vintageId", controller: "VintagesDetailsController"});
	this.route("vintages.edit", {path: "/vintages/edit/:vintageId", controller: "VintagesEditController"});
	this.route("varietals", {path: "/varietals", controller: "VarietalsController"});
	this.route("varietals.insert", {path: "/varietals/insert", controller: "VarietalsInsertController"});
	this.route("varietals.details", {path: "/varietals/details/:varietalId", controller: "VarietalsDetailsController"});
	this.route("varietals.edit", {path: "/varietals/edit/:varietalId", controller: "VarietalsEditController"});
	this.route("picklocations", {path: "/picklocations", controller: "PicklocationsController"});
	this.route("picklocations.insert", {path: "/picklocations/insert", controller: "PicklocationsInsertController"});
	this.route("picklocations.details", {path: "/picklocations/details/:picklocationId", controller: "PicklocationsDetailsController"});
	this.route("picklocations.edit", {path: "/picklocations/edit/:picklocationId", controller: "PicklocationsEditController"});
	this.route("picknumbers", {path: "/picknumbers", controller: "PicknumbersController"});
	this.route("picknumbers.insert", {path: "/picknumbers/insert", controller: "PicknumbersInsertController"});
	this.route("picknumbers.details", {path: "/picknumbers/details/:picknumberId", controller: "PicknumbersDetailsController"});
	this.route("picknumbers.edit", {path: "/picknumbers/edit/:picknumberId", controller: "PicknumbersEditController"});
	this.route("presss", {path: "/presss", controller: "PresssController"});
	this.route("presss.insert", {path: "/presss/insert", controller: "PresssInsertController"});
	this.route("presss.details", {path: "/presss/details/:pressId", controller: "PresssDetailsController"});
	this.route("presss.edit", {path: "/presss/edit/:pressId", controller: "PresssEditController"});
	this.route("tanks", {path: "/tanks", controller: "TanksController"});
	this.route("tanks.insert", {path: "/tanks/insert", controller: "TanksInsertController"});
	this.route("tanks.details", {path: "/tanks/details/:tankId", controller: "TanksDetailsController"});
	this.route("tanks.edit", {path: "/tanks/edit/:tankId", controller: "TanksEditController"});
	this.route("ttests", {path: "/ttests", controller: "TtestsController"});
	this.route("ttests.insert", {path: "/ttests/insert", controller: "TtestsInsertController"});
	this.route("ttests.details", {path: "/ttests/details/:testId", controller: "TtestsDetailsController"});
	this.route("ttests.edit", {path: "/ttests/edit/:testId", controller: "TtestsEditController"});
	this.route("barrels", {path: "/barrels", controller: "BarrelsController"});
	this.route("barrels.insert", {path: "/barrels/insert", controller: "BarrelsInsertController"});
	this.route("barrels.details", {path: "/barrels/details/:barrelId", controller: "BarrelsDetailsController"});
	this.route("barrels.edit", {path: "/barrels/edit/:barrelId", controller: "BarrelsEditController"});
	this.route("trxaddchemicaltotanks", {path: "/trxaddchemicaltotanks", controller: "TrxaddchemicaltotanksController"});
	this.route("trxaddchemicaltotanks.insert", {path: "/trxaddchemicaltotanks/insert", controller: "TrxaddchemicaltotanksInsertController"});
	this.route("trxaddchemicaltotanks.details", {path: "/trxaddchemicaltotanks/details/:trxaddchemicaltotankId", controller: "TrxaddchemicaltotanksDetailsController"});
	this.route("trxaddchemicaltotanks.edit", {path: "/trxaddchemicaltotanks/edit/:trxaddchemicaltotankId", controller: "TrxaddchemicaltotanksEditController"});
	this.route("trxbarreltotanks", {path: "/trxbarreltotanks", controller: "TrxbarreltotanksController"});
	this.route("trxbarreltotanks.insert", {path: "/trxbarreltotanks/insert", controller: "TrxbarreltotanksInsertController"});
	this.route("trxbarreltotanks.details", {path: "/trxbarreltotanks/details/:trxbarreltotankId", controller: "TrxbarreltotanksDetailsController"});
	this.route("trxbarreltotanks.edit", {path: "/trxbarreltotanks/edit/:trxbarreltotankId", controller: "TrxbarreltotanksEditController"});
	this.route("trxcleantanks", {path: "/trxcleantanks", controller: "TrxcleantanksController"});
	this.route("trxcleantanks.insert", {path: "/trxcleantanks/insert", controller: "TrxcleantanksInsertController"});
	this.route("trxcleantanks.details", {path: "/trxcleantanks/details/:trxcleantankId", controller: "TrxcleantanksDetailsController"});
	this.route("trxcleantanks.edit", {path: "/trxcleantanks/edit/:trxcleantankId", controller: "TrxcleantanksEditController"});
	this.route("trxtankcleaningchemicals", {path: "/trxtankcleaningchemicals", controller: "TrxtankcleaningchemicalsController"});
	this.route("trxtankcleaningchemicals.insert", {path: "/trxtankcleaningchemicals/insert", controller: "TrxtankcleaningchemicalsInsertController"});
	this.route("trxtankcleaningchemicals.details", {path: "/trxtankcleaningchemicals/details/:trxtankcleaningchemicalId", controller: "TrxtankcleaningchemicalsDetailsController"});
	this.route("trxtankcleaningchemicals.edit", {path: "/trxtankcleaningchemicals/edit/:trxtankcleaningchemicalId", controller: "TrxtankcleaningchemicalsEditController"});
	this.route("trxfilltanks", {path: "/trxfilltanks", controller: "TrxfilltanksController"});
	this.route("trxfilltanks.insert", {path: "/trxfilltanks/insert", controller: "TrxfilltanksInsertController"});
	this.route("trxfilltanks.details", {path: "/trxfilltanks/details/:trxfilltankId", controller: "TrxfilltanksDetailsController"});
	this.route("trxfilltanks.edit", {path: "/trxfilltanks/edit/:trxfilltankId", controller: "TrxfilltanksEditController"});
	this.route("trxtanktests", {path: "/trxtanktests", controller: "TrxtanktestsController"});
	this.route("trxtanktests.insert", {path: "/trxtanktests/insert", controller: "TrxtanktestsInsertController"});
	this.route("trxtanktests.details", {path: "/trxtanktests/details/:trxtanktestId", controller: "TrxtanktestsDetailsController"});
	this.route("trxtanktests.edit", {path: "/trxtanktests/edit/:trxtanktestId", controller: "TrxtanktestsEditController"});
	this.route("trxblendtoblends", {path: "/trxblendtoblends", controller: "TrxblendtoblendsController"});
	this.route("trxblendtoblends.insert", {path: "/trxblendtoblends/insert", controller: "TrxblendtoblendsInsertController"});
	this.route("trxblendtoblends.details", {path: "/trxblendtoblends/details/:trxblendtoblendId", controller: "TrxblendtoblendsDetailsController"});
	this.route("trxblendtoblends.edit", {path: "/trxblendtoblends/edit/:trxblendtoblendId", controller: "TrxblendtoblendsEditController"});
	this.route("trxlottoblends", {path: "/trxlottoblends", controller: "TrxlottoblendsController"});
	this.route("trxlottoblends.insert", {path: "/trxlottoblends/insert", controller: "TrxlottoblendsInsertController"});
	this.route("trxlottoblends.details", {path: "/trxlottoblends/details/:trxlottoblendId", controller: "TrxlottoblendsDetailsController"});
	this.route("trxlottoblends.edit", {path: "/trxlottoblends/edit/:trxlottoblendId", controller: "TrxlottoblendsEditController"});
});
