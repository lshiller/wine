this.ChemicalManufacturer = new Mongo.Collection("ChemicalManufacturer");

this.ChemicalManufacturer.userCanInsert = function(userId, doc) {
	return true;
};

this.ChemicalManufacturer.userCanUpdate = function(userId, doc) {
	return true;
};

this.ChemicalManufacturer.userCanRemove = function(userId, doc) {
	return true;
};
