var pageSession = new ReactiveDict();

Template.TrxfilltanksEdit.rendered = function() {
	
};

Template.TrxfilltanksEdit.events({
	
});

Template.TrxfilltanksEdit.helpers({
	
});

Template.TrxfilltanksEditEditForm.rendered = function() {
	

	pageSession.set("trxfilltanksEditEditFormInfoMessage", "");
	pageSession.set("trxfilltanksEditEditFormErrorMessage", "");

	$(".input-group.date").each(function() {
		var format = $(this).find("input[type='text']").attr("data-format");

		if(format) {
			format = format.toLowerCase();
		}
		else {
			format = "mm/dd/yyyy";
		}

		$(this).datepicker({
			autoclose: true,
			todayHighlight: true,
			todayBtn: true,
			forceParse: false,
			keyboardNavigation: false,
			format: format
		});
	});

	$("input[type='file']").fileinput();
	$("select[data-role='tagsinput']").tagsinput();
	$(".bootstrap-tagsinput").addClass("form-control");
	$("input[autofocus]").focus();
};

Template.TrxfilltanksEditEditForm.events({
	"submit": function(e, t) {
		e.preventDefault();
		pageSession.set("trxfilltanksEditEditFormInfoMessage", "");
		pageSession.set("trxfilltanksEditEditFormErrorMessage", "");

		var self = this;

		function submitAction(msg) {
			var trxfilltanksEditEditFormMode = "update";
			if(!t.find("#form-cancel-button")) {
				switch(trxfilltanksEditEditFormMode) {
					case "insert": {
						$(e.target)[0].reset();
					}; break;

					case "update": {
						var message = msg || "Saved.";
						pageSession.set("trxfilltanksEditEditFormInfoMessage", message);
					}; break;
				}
			}

			Router.go("trxfilltanks", {});
		}

		function errorAction(msg) {
			msg = msg || "";
			var message = msg.message || msg || "Error.";
			pageSession.set("trxfilltanksEditEditFormErrorMessage", message);
		}

		validateForm(
			$(e.target),
			function(fieldName, fieldValue) {

			},
			function(msg) {

			},
			function(values) {
				

				TrxFillTank.update({ _id: t.data.trxfilltank._id }, { $set: values }, function(e) { if(e) errorAction(e); else submitAction(); });
			}
		);

		return false;
	},
	"click #form-cancel-button": function(e, t) {
		e.preventDefault();

		

		Router.go("trxfilltanks", {});
	},
	"click #form-close-button": function(e, t) {
		e.preventDefault();

		/*CLOSE_REDIRECT*/
	},
	"click #form-back-button": function(e, t) {
		e.preventDefault();

		/*BACK_REDIRECT*/
	}

	
});

Template.TrxfilltanksEditEditForm.helpers({
	"infoMessage": function() {
		return pageSession.get("trxfilltanksEditEditFormInfoMessage");
	},
	"errorMessage": function() {
		return pageSession.get("trxfilltanksEditEditFormErrorMessage");
	}
	
});
