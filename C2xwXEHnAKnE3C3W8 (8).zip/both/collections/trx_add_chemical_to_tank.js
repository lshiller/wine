this.TrxAddChemicalToTank = new Mongo.Collection("TrxAddChemicalToTank");

this.TrxAddChemicalToTank.userCanInsert = function(userId, doc) {
	return true;
};

this.TrxAddChemicalToTank.userCanUpdate = function(userId, doc) {
	return true;
};

this.TrxAddChemicalToTank.userCanRemove = function(userId, doc) {
	return true;
};
