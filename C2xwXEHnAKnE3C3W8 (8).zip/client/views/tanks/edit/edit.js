var pageSession = new ReactiveDict();

Template.TanksEdit.rendered = function() {
	
};

Template.TanksEdit.events({
	
});

Template.TanksEdit.helpers({
	
});

Template.TanksEditEditForm.rendered = function() {
	

	pageSession.set("tanksEditEditFormInfoMessage", "");
	pageSession.set("tanksEditEditFormErrorMessage", "");

	$(".input-group.date").each(function() {
		var format = $(this).find("input[type='text']").attr("data-format");

		if(format) {
			format = format.toLowerCase();
		}
		else {
			format = "mm/dd/yyyy";
		}

		$(this).datepicker({
			autoclose: true,
			todayHighlight: true,
			todayBtn: true,
			forceParse: false,
			keyboardNavigation: false,
			format: format
		});
	});

	$("input[type='file']").fileinput();
	$("select[data-role='tagsinput']").tagsinput();
	$(".bootstrap-tagsinput").addClass("form-control");
	$("input[autofocus]").focus();
};

Template.TanksEditEditForm.events({
	"submit": function(e, t) {
		e.preventDefault();
		pageSession.set("tanksEditEditFormInfoMessage", "");
		pageSession.set("tanksEditEditFormErrorMessage", "");

		var self = this;

		function submitAction(msg) {
			var tanksEditEditFormMode = "update";
			if(!t.find("#form-cancel-button")) {
				switch(tanksEditEditFormMode) {
					case "insert": {
						$(e.target)[0].reset();
					}; break;

					case "update": {
						var message = msg || "Saved.";
						pageSession.set("tanksEditEditFormInfoMessage", message);
					}; break;
				}
			}

			Router.go("tanks", {});
		}

		function errorAction(msg) {
			msg = msg || "";
			var message = msg.message || msg || "Error.";
			pageSession.set("tanksEditEditFormErrorMessage", message);
		}

		validateForm(
			$(e.target),
			function(fieldName, fieldValue) {

			},
			function(msg) {

			},
			function(values) {
				

				Tank.update({ _id: t.data.tank._id }, { $set: values }, function(e) { if(e) errorAction(e); else submitAction(); });
			}
		);

		return false;
	},
	"click #form-cancel-button": function(e, t) {
		e.preventDefault();

		

		Router.go("tanks", {});
	},
	"click #form-close-button": function(e, t) {
		e.preventDefault();

		/*CLOSE_REDIRECT*/
	},
	"click #form-back-button": function(e, t) {
		e.preventDefault();

		/*BACK_REDIRECT*/
	}

	
});

Template.TanksEditEditForm.helpers({
	"infoMessage": function() {
		return pageSession.get("tanksEditEditFormInfoMessage");
	},
	"errorMessage": function() {
		return pageSession.get("tanksEditEditFormErrorMessage");
	}
	
});
