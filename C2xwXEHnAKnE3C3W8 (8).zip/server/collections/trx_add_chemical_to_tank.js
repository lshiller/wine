TrxAddChemicalToTank.allow({
	insert: function (userId, doc) {
		return TrxAddChemicalToTank.userCanInsert(userId, doc);
	},

	update: function (userId, doc, fields, modifier) {
		return TrxAddChemicalToTank.userCanUpdate(userId, doc);
	},

	remove: function (userId, doc) {
		return TrxAddChemicalToTank.userCanRemove(userId, doc);
	}
});

TrxAddChemicalToTank.before.insert(function(userId, doc) {
	doc.createdAt = new Date();
	doc.createdBy = userId;
	doc.modifiedAt = doc.createdAt;
	doc.modifiedBy = doc.createdBy;

	
	if(!doc.createdBy) doc.createdBy = userId;
});

TrxAddChemicalToTank.before.update(function(userId, doc, fieldNames, modifier, options) {
	modifier.$set = modifier.$set || {};
	modifier.$set.modifiedAt = new Date();
	modifier.$set.modifiedBy = userId;

	
});

TrxAddChemicalToTank.before.upsert(function(userId, selector, modifier, options) {
	modifier.$set = modifier.$set || {};
	modifier.$set.modifiedAt = new Date();
	modifier.$set.modifiedBy = userId;

	/*BEFORE_UPSERT_CODE*/
});

TrxAddChemicalToTank.before.remove(function(userId, doc) {
	
});

TrxAddChemicalToTank.after.insert(function(userId, doc) {
	
});

TrxAddChemicalToTank.after.update(function(userId, doc, fieldNames, modifier, options) {
	
});

TrxAddChemicalToTank.after.remove(function(userId, doc) {
	
});
