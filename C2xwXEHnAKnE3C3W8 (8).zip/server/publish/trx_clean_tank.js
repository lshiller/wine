Meteor.publish("trxcleantank", function(trxcleantankId) {
	return TrxCleanTank.find({_id:trxcleantankId}, {});
});

Meteor.publish("trxcleantanks", function() {
	return TrxCleanTank.find({}, {});
});

Meteor.publish("trxcleantanks_empty", function() {
	return TrxCleanTank.find({_id:null}, {});
});

