this.TrxBlendToBlend = new Mongo.Collection("TrxBlendToBlend");

this.TrxBlendToBlend.userCanInsert = function(userId, doc) {
	return true;
};

this.TrxBlendToBlend.userCanUpdate = function(userId, doc) {
	return true;
};

this.TrxBlendToBlend.userCanRemove = function(userId, doc) {
	return true;
};
