var pageSession = new ReactiveDict();

Template.TrxcleantanksInsert.rendered = function() {
	
};

Template.TrxcleantanksInsert.events({
	
});

Template.TrxcleantanksInsert.helpers({
	
});

Template.TrxcleantanksInsertInsertForm.rendered = function() {
	

	pageSession.set("trxcleantanksInsertInsertFormInfoMessage", "");
	pageSession.set("trxcleantanksInsertInsertFormErrorMessage", "");

	$(".input-group.date").each(function() {
		var format = $(this).find("input[type='text']").attr("data-format");

		if(format) {
			format = format.toLowerCase();
		}
		else {
			format = "mm/dd/yyyy";
		}

		$(this).datepicker({
			autoclose: true,
			todayHighlight: true,
			todayBtn: true,
			forceParse: false,
			keyboardNavigation: false,
			format: format
		});
	});

	$("input[type='file']").fileinput();
	$("select[data-role='tagsinput']").tagsinput();
	$(".bootstrap-tagsinput").addClass("form-control");
	$("input[autofocus]").focus();
};

Template.TrxcleantanksInsertInsertForm.events({
	"submit": function(e, t) {
		e.preventDefault();
		pageSession.set("trxcleantanksInsertInsertFormInfoMessage", "");
		pageSession.set("trxcleantanksInsertInsertFormErrorMessage", "");

		var self = this;

		function submitAction(msg) {
			var trxcleantanksInsertInsertFormMode = "insert";
			if(!t.find("#form-cancel-button")) {
				switch(trxcleantanksInsertInsertFormMode) {
					case "insert": {
						$(e.target)[0].reset();
					}; break;

					case "update": {
						var message = msg || "Saved.";
						pageSession.set("trxcleantanksInsertInsertFormInfoMessage", message);
					}; break;
				}
			}

			Router.go("trxcleantanks", {});
		}

		function errorAction(msg) {
			msg = msg || "";
			var message = msg.message || msg || "Error.";
			pageSession.set("trxcleantanksInsertInsertFormErrorMessage", message);
		}

		validateForm(
			$(e.target),
			function(fieldName, fieldValue) {

			},
			function(msg) {

			},
			function(values) {
				

				newId = TrxCleanTank.insert(values, function(e) { if(e) errorAction(e); else submitAction(); });
			}
		);

		return false;
	},
	"click #form-cancel-button": function(e, t) {
		e.preventDefault();

		

		Router.go("trxcleantanks", {});
	},
	"click #form-close-button": function(e, t) {
		e.preventDefault();

		/*CLOSE_REDIRECT*/
	},
	"click #form-back-button": function(e, t) {
		e.preventDefault();

		/*BACK_REDIRECT*/
	}

	
});

Template.TrxcleantanksInsertInsertForm.helpers({
	"infoMessage": function() {
		return pageSession.get("trxcleantanksInsertInsertFormInfoMessage");
	},
	"errorMessage": function() {
		return pageSession.get("trxcleantanksInsertInsertFormErrorMessage");
	}
	
});
