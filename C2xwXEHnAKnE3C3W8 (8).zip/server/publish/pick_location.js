Meteor.publish("picklocation", function(picklocationId) {
	return PickLocation.find({_id:picklocationId}, {});
});

Meteor.publish("picklocations", function() {
	return PickLocation.find({}, {});
});

Meteor.publish("picklocations_empty", function() {
	return PickLocation.find({_id:null}, {});
});

