var pageSession = new ReactiveDict();

Template.TrxlottoblendsInsert.rendered = function() {
	
};

Template.TrxlottoblendsInsert.events({
	
});

Template.TrxlottoblendsInsert.helpers({
	
});

Template.TrxlottoblendsInsertInsertForm.rendered = function() {
	

	pageSession.set("trxlottoblendsInsertInsertFormInfoMessage", "");
	pageSession.set("trxlottoblendsInsertInsertFormErrorMessage", "");

	$(".input-group.date").each(function() {
		var format = $(this).find("input[type='text']").attr("data-format");

		if(format) {
			format = format.toLowerCase();
		}
		else {
			format = "mm/dd/yyyy";
		}

		$(this).datepicker({
			autoclose: true,
			todayHighlight: true,
			todayBtn: true,
			forceParse: false,
			keyboardNavigation: false,
			format: format
		});
	});

	$("input[type='file']").fileinput();
	$("select[data-role='tagsinput']").tagsinput();
	$(".bootstrap-tagsinput").addClass("form-control");
	$("input[autofocus]").focus();
};

Template.TrxlottoblendsInsertInsertForm.events({
	"submit": function(e, t) {
		e.preventDefault();
		pageSession.set("trxlottoblendsInsertInsertFormInfoMessage", "");
		pageSession.set("trxlottoblendsInsertInsertFormErrorMessage", "");

		var self = this;

		function submitAction(msg) {
			var trxlottoblendsInsertInsertFormMode = "insert";
			if(!t.find("#form-cancel-button")) {
				switch(trxlottoblendsInsertInsertFormMode) {
					case "insert": {
						$(e.target)[0].reset();
					}; break;

					case "update": {
						var message = msg || "Saved.";
						pageSession.set("trxlottoblendsInsertInsertFormInfoMessage", message);
					}; break;
				}
			}

			Router.go("trxlottoblends", {});
		}

		function errorAction(msg) {
			msg = msg || "";
			var message = msg.message || msg || "Error.";
			pageSession.set("trxlottoblendsInsertInsertFormErrorMessage", message);
		}

		validateForm(
			$(e.target),
			function(fieldName, fieldValue) {

			},
			function(msg) {

			},
			function(values) {
				

				newId = TrxLotToBlend.insert(values, function(e) { if(e) errorAction(e); else submitAction(); });
			}
		);

		return false;
	},
	"click #form-cancel-button": function(e, t) {
		e.preventDefault();

		

		Router.go("trxlottoblends", {});
	},
	"click #form-close-button": function(e, t) {
		e.preventDefault();

		/*CLOSE_REDIRECT*/
	},
	"click #form-back-button": function(e, t) {
		e.preventDefault();

		/*BACK_REDIRECT*/
	}

	
});

Template.TrxlottoblendsInsertInsertForm.helpers({
	"infoMessage": function() {
		return pageSession.get("trxlottoblendsInsertInsertFormInfoMessage");
	},
	"errorMessage": function() {
		return pageSession.get("trxlottoblendsInsertInsertFormErrorMessage");
	}
	
});
