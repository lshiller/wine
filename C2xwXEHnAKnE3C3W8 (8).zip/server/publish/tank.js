Meteor.publish("tank", function(tankId) {
	return Tank.find({_id:tankId}, {});
});

Meteor.publish("tanks", function() {
	return Tank.find({}, {});
});

Meteor.publish("tanks_empty", function() {
	return Tank.find({_id:null}, {});
});

