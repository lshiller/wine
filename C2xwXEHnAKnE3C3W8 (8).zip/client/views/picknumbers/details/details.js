var pageSession = new ReactiveDict();

Template.PicknumbersDetails.rendered = function() {
	
};

Template.PicknumbersDetails.events({
	
});

Template.PicknumbersDetails.helpers({
	
});

Template.PicknumbersDetailsDetailsForm.rendered = function() {
	

	pageSession.set("picknumbersDetailsDetailsFormInfoMessage", "");
	pageSession.set("picknumbersDetailsDetailsFormErrorMessage", "");

	$(".input-group.date").each(function() {
		var format = $(this).find("input[type='text']").attr("data-format");

		if(format) {
			format = format.toLowerCase();
		}
		else {
			format = "mm/dd/yyyy";
		}

		$(this).datepicker({
			autoclose: true,
			todayHighlight: true,
			todayBtn: true,
			forceParse: false,
			keyboardNavigation: false,
			format: format
		});
	});

	$("input[type='file']").fileinput();
	$("select[data-role='tagsinput']").tagsinput();
	$(".bootstrap-tagsinput").addClass("form-control");
	$("input[autofocus]").focus();
};

Template.PicknumbersDetailsDetailsForm.events({
	"submit": function(e, t) {
		e.preventDefault();
		pageSession.set("picknumbersDetailsDetailsFormInfoMessage", "");
		pageSession.set("picknumbersDetailsDetailsFormErrorMessage", "");

		var self = this;

		function submitAction(msg) {
			var picknumbersDetailsDetailsFormMode = "read_only";
			if(!t.find("#form-cancel-button")) {
				switch(picknumbersDetailsDetailsFormMode) {
					case "insert": {
						$(e.target)[0].reset();
					}; break;

					case "update": {
						var message = msg || "Saved.";
						pageSession.set("picknumbersDetailsDetailsFormInfoMessage", message);
					}; break;
				}
			}

			/*SUBMIT_REDIRECT*/
		}

		function errorAction(msg) {
			msg = msg || "";
			var message = msg.message || msg || "Error.";
			pageSession.set("picknumbersDetailsDetailsFormErrorMessage", message);
		}

		validateForm(
			$(e.target),
			function(fieldName, fieldValue) {

			},
			function(msg) {

			},
			function(values) {
				

				
			}
		);

		return false;
	},
	"click #form-cancel-button": function(e, t) {
		e.preventDefault();

		

		/*CANCEL_REDIRECT*/
	},
	"click #form-close-button": function(e, t) {
		e.preventDefault();

		Router.go("picknumbers", {});
	},
	"click #form-back-button": function(e, t) {
		e.preventDefault();

		Router.go("picknumbers", {});
	}

	
});

Template.PicknumbersDetailsDetailsForm.helpers({
	"infoMessage": function() {
		return pageSession.get("picknumbersDetailsDetailsFormInfoMessage");
	},
	"errorMessage": function() {
		return pageSession.get("picknumbersDetailsDetailsFormErrorMessage");
	}
	
});
