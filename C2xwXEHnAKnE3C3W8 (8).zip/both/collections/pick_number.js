this.PickNumber = new Mongo.Collection("PickNumber");

this.PickNumber.userCanInsert = function(userId, doc) {
	return true;
};

this.PickNumber.userCanUpdate = function(userId, doc) {
	return true;
};

this.PickNumber.userCanRemove = function(userId, doc) {
	return true;
};
