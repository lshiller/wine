this.TrxCleanTank = new Mongo.Collection("TrxCleanTank");

this.TrxCleanTank.userCanInsert = function(userId, doc) {
	return true;
};

this.TrxCleanTank.userCanUpdate = function(userId, doc) {
	return true;
};

this.TrxCleanTank.userCanRemove = function(userId, doc) {
	return true;
};
