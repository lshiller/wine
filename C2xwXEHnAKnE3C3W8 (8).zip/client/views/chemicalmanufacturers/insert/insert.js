var pageSession = new ReactiveDict();

Template.ChemicalmanufacturersInsert.rendered = function() {
	
};

Template.ChemicalmanufacturersInsert.events({
	
});

Template.ChemicalmanufacturersInsert.helpers({
	
});

Template.ChemicalmanufacturersInsertInsertForm.rendered = function() {
	

	pageSession.set("chemicalmanufacturersInsertInsertFormInfoMessage", "");
	pageSession.set("chemicalmanufacturersInsertInsertFormErrorMessage", "");

	$(".input-group.date").each(function() {
		var format = $(this).find("input[type='text']").attr("data-format");

		if(format) {
			format = format.toLowerCase();
		}
		else {
			format = "mm/dd/yyyy";
		}

		$(this).datepicker({
			autoclose: true,
			todayHighlight: true,
			todayBtn: true,
			forceParse: false,
			keyboardNavigation: false,
			format: format
		});
	});

	$("input[type='file']").fileinput();
	$("select[data-role='tagsinput']").tagsinput();
	$(".bootstrap-tagsinput").addClass("form-control");
	$("input[autofocus]").focus();
};

Template.ChemicalmanufacturersInsertInsertForm.events({
	"submit": function(e, t) {
		e.preventDefault();
		pageSession.set("chemicalmanufacturersInsertInsertFormInfoMessage", "");
		pageSession.set("chemicalmanufacturersInsertInsertFormErrorMessage", "");

		var self = this;

		function submitAction(msg) {
			var chemicalmanufacturersInsertInsertFormMode = "insert";
			if(!t.find("#form-cancel-button")) {
				switch(chemicalmanufacturersInsertInsertFormMode) {
					case "insert": {
						$(e.target)[0].reset();
					}; break;

					case "update": {
						var message = msg || "Saved.";
						pageSession.set("chemicalmanufacturersInsertInsertFormInfoMessage", message);
					}; break;
				}
			}

			Router.go("chemicalmanufacturers", {});
		}

		function errorAction(msg) {
			msg = msg || "";
			var message = msg.message || msg || "Error.";
			pageSession.set("chemicalmanufacturersInsertInsertFormErrorMessage", message);
		}

		validateForm(
			$(e.target),
			function(fieldName, fieldValue) {

			},
			function(msg) {

			},
			function(values) {
				

				newId = ChemicalManufacturer.insert(values, function(e) { if(e) errorAction(e); else submitAction(); });
			}
		);

		return false;
	},
	"click #form-cancel-button": function(e, t) {
		e.preventDefault();

		

		Router.go("chemicalmanufacturers", {});
	},
	"click #form-close-button": function(e, t) {
		e.preventDefault();

		/*CLOSE_REDIRECT*/
	},
	"click #form-back-button": function(e, t) {
		e.preventDefault();

		/*BACK_REDIRECT*/
	}

	
});

Template.ChemicalmanufacturersInsertInsertForm.helpers({
	"infoMessage": function() {
		return pageSession.get("chemicalmanufacturersInsertInsertFormInfoMessage");
	},
	"errorMessage": function() {
		return pageSession.get("chemicalmanufacturersInsertInsertFormErrorMessage");
	}
	
});
