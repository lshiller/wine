var pageSession = new ReactiveDict();

Template.TtestsEdit.rendered = function() {
	
};

Template.TtestsEdit.events({
	
});

Template.TtestsEdit.helpers({
	
});

Template.TtestsEditEditForm.rendered = function() {
	

	pageSession.set("ttestsEditEditFormInfoMessage", "");
	pageSession.set("ttestsEditEditFormErrorMessage", "");

	$(".input-group.date").each(function() {
		var format = $(this).find("input[type='text']").attr("data-format");

		if(format) {
			format = format.toLowerCase();
		}
		else {
			format = "mm/dd/yyyy";
		}

		$(this).datepicker({
			autoclose: true,
			todayHighlight: true,
			todayBtn: true,
			forceParse: false,
			keyboardNavigation: false,
			format: format
		});
	});

	$("input[type='file']").fileinput();
	$("select[data-role='tagsinput']").tagsinput();
	$(".bootstrap-tagsinput").addClass("form-control");
	$("input[autofocus]").focus();
};

Template.TtestsEditEditForm.events({
	"submit": function(e, t) {
		e.preventDefault();
		pageSession.set("ttestsEditEditFormInfoMessage", "");
		pageSession.set("ttestsEditEditFormErrorMessage", "");

		var self = this;

		function submitAction(msg) {
			var ttestsEditEditFormMode = "update";
			if(!t.find("#form-cancel-button")) {
				switch(ttestsEditEditFormMode) {
					case "insert": {
						$(e.target)[0].reset();
					}; break;

					case "update": {
						var message = msg || "Saved.";
						pageSession.set("ttestsEditEditFormInfoMessage", message);
					}; break;
				}
			}

			Router.go("ttests", {});
		}

		function errorAction(msg) {
			msg = msg || "";
			var message = msg.message || msg || "Error.";
			pageSession.set("ttestsEditEditFormErrorMessage", message);
		}

		validateForm(
			$(e.target),
			function(fieldName, fieldValue) {

			},
			function(msg) {

			},
			function(values) {
				

				Test.update({ _id: t.data.test._id }, { $set: values }, function(e) { if(e) errorAction(e); else submitAction(); });
			}
		);

		return false;
	},
	"click #form-cancel-button": function(e, t) {
		e.preventDefault();

		

		Router.go("ttests", {});
	},
	"click #form-close-button": function(e, t) {
		e.preventDefault();

		/*CLOSE_REDIRECT*/
	},
	"click #form-back-button": function(e, t) {
		e.preventDefault();

		/*BACK_REDIRECT*/
	}

	
});

Template.TtestsEditEditForm.helpers({
	"infoMessage": function() {
		return pageSession.get("ttestsEditEditFormInfoMessage");
	},
	"errorMessage": function() {
		return pageSession.get("ttestsEditEditFormErrorMessage");
	}
	
});
