this.Blend = new Mongo.Collection("Blend");

this.Blend.userCanInsert = function(userId, doc) {
	return true;
};

this.Blend.userCanUpdate = function(userId, doc) {
	return true;
};

this.Blend.userCanRemove = function(userId, doc) {
	return true;
};
