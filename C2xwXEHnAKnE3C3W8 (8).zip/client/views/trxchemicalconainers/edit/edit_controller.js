this.TrxchemicalconainersEditController = RouteController.extend({
	template: "TrxchemicalconainersEdit",
	

	yieldTemplates: {
		/*YIELD_TEMPLATES*/
	},

	onBeforeAction: function() {
		this.next();
	},

	action: function() {
		if(this.isReady()) { this.render(); } else { this.render("loading"); }
		/*ACTION_FUNCTION*/
	},

	isReady: function() {
		

		var subs = [
			Meteor.subscribe("chemicalmanufacturers"),
			Meteor.subscribe("chemicals"),
			Meteor.subscribe("units"),
			Meteor.subscribe("trxchemicalconainer", this.params.trxchemicalconainerId)
		];
		var ready = true;
		_.each(subs, function(sub) {
			if(!sub.ready())
				ready = false;
		});
		return ready;
	},

	data: function() {
		

		var data = {
			params: this.params || {},
			chemicalmanufacturers: ChemicalManufacturer.find({}, {}),
			chemicals: Chemical.find({}, {}),
			units: Unit.find({}, {}),
			trxchemicalconainer: TrxChemicalContainer.findOne({_id:this.params.trxchemicalconainerId}, {})
		};
		

		

		return data;
	},

	onAfterAction: function() {
		
	}
});