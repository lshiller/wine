TrxFillTank.allow({
	insert: function (userId, doc) {
		return TrxFillTank.userCanInsert(userId, doc);
	},

	update: function (userId, doc, fields, modifier) {
		return TrxFillTank.userCanUpdate(userId, doc);
	},

	remove: function (userId, doc) {
		return TrxFillTank.userCanRemove(userId, doc);
	}
});

TrxFillTank.before.insert(function(userId, doc) {
	doc.createdAt = new Date();
	doc.createdBy = userId;
	doc.modifiedAt = doc.createdAt;
	doc.modifiedBy = doc.createdBy;

	
	if(!doc.createdBy) doc.createdBy = userId;
});

TrxFillTank.before.update(function(userId, doc, fieldNames, modifier, options) {
	modifier.$set = modifier.$set || {};
	modifier.$set.modifiedAt = new Date();
	modifier.$set.modifiedBy = userId;

	
});

TrxFillTank.before.upsert(function(userId, selector, modifier, options) {
	modifier.$set = modifier.$set || {};
	modifier.$set.modifiedAt = new Date();
	modifier.$set.modifiedBy = userId;

	/*BEFORE_UPSERT_CODE*/
});

TrxFillTank.before.remove(function(userId, doc) {
	
});

TrxFillTank.after.insert(function(userId, doc) {
	
});

TrxFillTank.after.update(function(userId, doc, fieldNames, modifier, options) {
	
});

TrxFillTank.after.remove(function(userId, doc) {
	
});
