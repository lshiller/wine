Meteor.publish("chemicalmanufacturer", function(chemicalmanufacturerId) {
	return ChemicalManufacturer.find({_id:chemicalmanufacturerId}, {});
});

Meteor.publish("chemicalmanufacturers", function() {
	return ChemicalManufacturer.find({}, {});
});

Meteor.publish("chemicalmanufacturers_empty", function() {
	return ChemicalManufacturer.find({_id:null}, {});
});

