TrxTankCleaningChemical.allow({
	insert: function (userId, doc) {
		return TrxTankCleaningChemical.userCanInsert(userId, doc);
	},

	update: function (userId, doc, fields, modifier) {
		return TrxTankCleaningChemical.userCanUpdate(userId, doc);
	},

	remove: function (userId, doc) {
		return TrxTankCleaningChemical.userCanRemove(userId, doc);
	}
});

TrxTankCleaningChemical.before.insert(function(userId, doc) {
	doc.createdAt = new Date();
	doc.createdBy = userId;
	doc.modifiedAt = doc.createdAt;
	doc.modifiedBy = doc.createdBy;

	
	if(!doc.createdBy) doc.createdBy = userId;
});

TrxTankCleaningChemical.before.update(function(userId, doc, fieldNames, modifier, options) {
	modifier.$set = modifier.$set || {};
	modifier.$set.modifiedAt = new Date();
	modifier.$set.modifiedBy = userId;

	
});

TrxTankCleaningChemical.before.upsert(function(userId, selector, modifier, options) {
	modifier.$set = modifier.$set || {};
	modifier.$set.modifiedAt = new Date();
	modifier.$set.modifiedBy = userId;

	/*BEFORE_UPSERT_CODE*/
});

TrxTankCleaningChemical.before.remove(function(userId, doc) {
	
});

TrxTankCleaningChemical.after.insert(function(userId, doc) {
	
});

TrxTankCleaningChemical.after.update(function(userId, doc, fieldNames, modifier, options) {
	
});

TrxTankCleaningChemical.after.remove(function(userId, doc) {
	
});
