this.TrxBarrelToTank = new Mongo.Collection("TrxBarrelToTank");

this.TrxBarrelToTank.userCanInsert = function(userId, doc) {
	return true;
};

this.TrxBarrelToTank.userCanUpdate = function(userId, doc) {
	return true;
};

this.TrxBarrelToTank.userCanRemove = function(userId, doc) {
	return true;
};
