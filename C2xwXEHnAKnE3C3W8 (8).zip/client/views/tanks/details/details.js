var pageSession = new ReactiveDict();

Template.TanksDetails.rendered = function() {
	
};

Template.TanksDetails.events({
	
});

Template.TanksDetails.helpers({
	
});

Template.TanksDetailsDetailsForm.rendered = function() {
	

	pageSession.set("tanksDetailsDetailsFormInfoMessage", "");
	pageSession.set("tanksDetailsDetailsFormErrorMessage", "");

	$(".input-group.date").each(function() {
		var format = $(this).find("input[type='text']").attr("data-format");

		if(format) {
			format = format.toLowerCase();
		}
		else {
			format = "mm/dd/yyyy";
		}

		$(this).datepicker({
			autoclose: true,
			todayHighlight: true,
			todayBtn: true,
			forceParse: false,
			keyboardNavigation: false,
			format: format
		});
	});

	$("input[type='file']").fileinput();
	$("select[data-role='tagsinput']").tagsinput();
	$(".bootstrap-tagsinput").addClass("form-control");
	$("input[autofocus]").focus();
};

Template.TanksDetailsDetailsForm.events({
	"submit": function(e, t) {
		e.preventDefault();
		pageSession.set("tanksDetailsDetailsFormInfoMessage", "");
		pageSession.set("tanksDetailsDetailsFormErrorMessage", "");

		var self = this;

		function submitAction(msg) {
			var tanksDetailsDetailsFormMode = "read_only";
			if(!t.find("#form-cancel-button")) {
				switch(tanksDetailsDetailsFormMode) {
					case "insert": {
						$(e.target)[0].reset();
					}; break;

					case "update": {
						var message = msg || "Saved.";
						pageSession.set("tanksDetailsDetailsFormInfoMessage", message);
					}; break;
				}
			}

			/*SUBMIT_REDIRECT*/
		}

		function errorAction(msg) {
			msg = msg || "";
			var message = msg.message || msg || "Error.";
			pageSession.set("tanksDetailsDetailsFormErrorMessage", message);
		}

		validateForm(
			$(e.target),
			function(fieldName, fieldValue) {

			},
			function(msg) {

			},
			function(values) {
				

				
			}
		);

		return false;
	},
	"click #form-cancel-button": function(e, t) {
		e.preventDefault();

		

		/*CANCEL_REDIRECT*/
	},
	"click #form-close-button": function(e, t) {
		e.preventDefault();

		Router.go("tanks", {});
	},
	"click #form-back-button": function(e, t) {
		e.preventDefault();

		Router.go("tanks", {});
	}

	
});

Template.TanksDetailsDetailsForm.helpers({
	"infoMessage": function() {
		return pageSession.get("tanksDetailsDetailsFormInfoMessage");
	},
	"errorMessage": function() {
		return pageSession.get("tanksDetailsDetailsFormErrorMessage");
	}
	
});
