var pageSession = new ReactiveDict();

Template.TrxchemicalconainersInsert.rendered = function() {
	
};

Template.TrxchemicalconainersInsert.events({
	
});

Template.TrxchemicalconainersInsert.helpers({
	
});

Template.TrxchemicalconainersInsertInsertForm.rendered = function() {
	

	pageSession.set("trxchemicalconainersInsertInsertFormInfoMessage", "");
	pageSession.set("trxchemicalconainersInsertInsertFormErrorMessage", "");

	$(".input-group.date").each(function() {
		var format = $(this).find("input[type='text']").attr("data-format");

		if(format) {
			format = format.toLowerCase();
		}
		else {
			format = "mm/dd/yyyy";
		}

		$(this).datepicker({
			autoclose: true,
			todayHighlight: true,
			todayBtn: true,
			forceParse: false,
			keyboardNavigation: false,
			format: format
		});
	});

	$("input[type='file']").fileinput();
	$("select[data-role='tagsinput']").tagsinput();
	$(".bootstrap-tagsinput").addClass("form-control");
	$("input[autofocus]").focus();
};

Template.TrxchemicalconainersInsertInsertForm.events({
	"submit": function(e, t) {
		e.preventDefault();
		pageSession.set("trxchemicalconainersInsertInsertFormInfoMessage", "");
		pageSession.set("trxchemicalconainersInsertInsertFormErrorMessage", "");

		var self = this;

		function submitAction(msg) {
			var trxchemicalconainersInsertInsertFormMode = "insert";
			if(!t.find("#form-cancel-button")) {
				switch(trxchemicalconainersInsertInsertFormMode) {
					case "insert": {
						$(e.target)[0].reset();
					}; break;

					case "update": {
						var message = msg || "Saved.";
						pageSession.set("trxchemicalconainersInsertInsertFormInfoMessage", message);
					}; break;
				}
			}

			Router.go("trxchemicalconainers", {});
		}

		function errorAction(msg) {
			msg = msg || "";
			var message = msg.message || msg || "Error.";
			pageSession.set("trxchemicalconainersInsertInsertFormErrorMessage", message);
		}

		validateForm(
			$(e.target),
			function(fieldName, fieldValue) {

			},
			function(msg) {

			},
			function(values) {
				

				newId = TrxChemicalContainer.insert(values, function(e) { if(e) errorAction(e); else submitAction(); });
			}
		);

		return false;
	},
	"click #form-cancel-button": function(e, t) {
		e.preventDefault();

		

		Router.go("trxchemicalconainers", {});
	},
	"click #form-close-button": function(e, t) {
		e.preventDefault();

		/*CLOSE_REDIRECT*/
	},
	"click #form-back-button": function(e, t) {
		e.preventDefault();

		/*BACK_REDIRECT*/
	}

	
});

Template.TrxchemicalconainersInsertInsertForm.helpers({
	"infoMessage": function() {
		return pageSession.get("trxchemicalconainersInsertInsertFormInfoMessage");
	},
	"errorMessage": function() {
		return pageSession.get("trxchemicalconainersInsertInsertFormErrorMessage");
	}
	
});
