TrxBlendToBlend.allow({
	insert: function (userId, doc) {
		return TrxBlendToBlend.userCanInsert(userId, doc);
	},

	update: function (userId, doc, fields, modifier) {
		return TrxBlendToBlend.userCanUpdate(userId, doc);
	},

	remove: function (userId, doc) {
		return TrxBlendToBlend.userCanRemove(userId, doc);
	}
});

TrxBlendToBlend.before.insert(function(userId, doc) {
	doc.createdAt = new Date();
	doc.createdBy = userId;
	doc.modifiedAt = doc.createdAt;
	doc.modifiedBy = doc.createdBy;

	
	if(!doc.createdBy) doc.createdBy = userId;
});

TrxBlendToBlend.before.update(function(userId, doc, fieldNames, modifier, options) {
	modifier.$set = modifier.$set || {};
	modifier.$set.modifiedAt = new Date();
	modifier.$set.modifiedBy = userId;

	
});

TrxBlendToBlend.before.upsert(function(userId, selector, modifier, options) {
	modifier.$set = modifier.$set || {};
	modifier.$set.modifiedAt = new Date();
	modifier.$set.modifiedBy = userId;

	/*BEFORE_UPSERT_CODE*/
});

TrxBlendToBlend.before.remove(function(userId, doc) {
	
});

TrxBlendToBlend.after.insert(function(userId, doc) {
	
});

TrxBlendToBlend.after.update(function(userId, doc, fieldNames, modifier, options) {
	
});

TrxBlendToBlend.after.remove(function(userId, doc) {
	
});
