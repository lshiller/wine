Meteor.publish("trxfilltank", function(trxfilltankId) {
	return TrxFillTank.find({_id:trxfilltankId}, {});
});

Meteor.publish("trxfilltanks", function() {
	return TrxFillTank.find({}, {});
});

Meteor.publish("trxfilltanks_empty", function() {
	return TrxFillTank.find({_id:null}, {});
});

