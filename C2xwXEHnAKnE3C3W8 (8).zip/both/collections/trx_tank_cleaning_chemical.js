this.TrxTankCleaningChemical = new Mongo.Collection("TrxTankCleaningChemical");

this.TrxTankCleaningChemical.userCanInsert = function(userId, doc) {
	return true;
};

this.TrxTankCleaningChemical.userCanUpdate = function(userId, doc) {
	return true;
};

this.TrxTankCleaningChemical.userCanRemove = function(userId, doc) {
	return true;
};
