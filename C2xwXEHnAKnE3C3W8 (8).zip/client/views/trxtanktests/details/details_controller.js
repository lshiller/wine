this.TrxtanktestsDetailsController = RouteController.extend({
	template: "TrxtanktestsDetails",
	

	yieldTemplates: {
		/*YIELD_TEMPLATES*/
	},

	onBeforeAction: function() {
		this.next();
	},

	action: function() {
		if(this.isReady()) { this.render(); } else { this.render("loading"); }
		/*ACTION_FUNCTION*/
	},

	isReady: function() {
		

		var subs = [
			Meteor.subscribe("trxtanktest", this.params.trxtanktestId)
		];
		var ready = true;
		_.each(subs, function(sub) {
			if(!sub.ready())
				ready = false;
		});
		return ready;
	},

	data: function() {
		

		var data = {
			params: this.params || {},
			trxtanktest: TrxTankTest.findOne({_id:this.params.trxtanktestId}, {})
		};
		

		

		return data;
	},

	onAfterAction: function() {
		
	}
});