this.TrxTankTest = new Mongo.Collection("TrxTankTest");

this.TrxTankTest.userCanInsert = function(userId, doc) {
	return true;
};

this.TrxTankTest.userCanUpdate = function(userId, doc) {
	return true;
};

this.TrxTankTest.userCanRemove = function(userId, doc) {
	return true;
};
