Meteor.publish("trxbarreltotank", function(trxbarreltotankId) {
	return TrxBarrelToTank.find({_id:trxbarreltotankId}, {});
});

Meteor.publish("trxbarreltotanks", function() {
	return TrxBarrelToTank.find({}, {});
});

Meteor.publish("trxbarreltotanks_empty", function() {
	return TrxBarrelToTank.find({_id:null}, {});
});

