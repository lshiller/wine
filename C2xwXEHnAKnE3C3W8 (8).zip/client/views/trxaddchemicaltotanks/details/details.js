var pageSession = new ReactiveDict();

Template.TrxaddchemicaltotanksDetails.rendered = function() {
	
};

Template.TrxaddchemicaltotanksDetails.events({
	
});

Template.TrxaddchemicaltotanksDetails.helpers({
	
});

Template.TrxaddchemicaltotanksDetailsDetailsForm.rendered = function() {
	

	pageSession.set("trxaddchemicaltotanksDetailsDetailsFormInfoMessage", "");
	pageSession.set("trxaddchemicaltotanksDetailsDetailsFormErrorMessage", "");

	$(".input-group.date").each(function() {
		var format = $(this).find("input[type='text']").attr("data-format");

		if(format) {
			format = format.toLowerCase();
		}
		else {
			format = "mm/dd/yyyy";
		}

		$(this).datepicker({
			autoclose: true,
			todayHighlight: true,
			todayBtn: true,
			forceParse: false,
			keyboardNavigation: false,
			format: format
		});
	});

	$("input[type='file']").fileinput();
	$("select[data-role='tagsinput']").tagsinput();
	$(".bootstrap-tagsinput").addClass("form-control");
	$("input[autofocus]").focus();
};

Template.TrxaddchemicaltotanksDetailsDetailsForm.events({
	"submit": function(e, t) {
		e.preventDefault();
		pageSession.set("trxaddchemicaltotanksDetailsDetailsFormInfoMessage", "");
		pageSession.set("trxaddchemicaltotanksDetailsDetailsFormErrorMessage", "");

		var self = this;

		function submitAction(msg) {
			var trxaddchemicaltotanksDetailsDetailsFormMode = "read_only";
			if(!t.find("#form-cancel-button")) {
				switch(trxaddchemicaltotanksDetailsDetailsFormMode) {
					case "insert": {
						$(e.target)[0].reset();
					}; break;

					case "update": {
						var message = msg || "Saved.";
						pageSession.set("trxaddchemicaltotanksDetailsDetailsFormInfoMessage", message);
					}; break;
				}
			}

			/*SUBMIT_REDIRECT*/
		}

		function errorAction(msg) {
			msg = msg || "";
			var message = msg.message || msg || "Error.";
			pageSession.set("trxaddchemicaltotanksDetailsDetailsFormErrorMessage", message);
		}

		validateForm(
			$(e.target),
			function(fieldName, fieldValue) {

			},
			function(msg) {

			},
			function(values) {
				

				
			}
		);

		return false;
	},
	"click #form-cancel-button": function(e, t) {
		e.preventDefault();

		

		/*CANCEL_REDIRECT*/
	},
	"click #form-close-button": function(e, t) {
		e.preventDefault();

		Router.go("trxaddchemicaltotanks", {});
	},
	"click #form-back-button": function(e, t) {
		e.preventDefault();

		Router.go("trxaddchemicaltotanks", {});
	}

	
});

Template.TrxaddchemicaltotanksDetailsDetailsForm.helpers({
	"infoMessage": function() {
		return pageSession.get("trxaddchemicaltotanksDetailsDetailsFormInfoMessage");
	},
	"errorMessage": function() {
		return pageSession.get("trxaddchemicaltotanksDetailsDetailsFormErrorMessage");
	}
	
});
