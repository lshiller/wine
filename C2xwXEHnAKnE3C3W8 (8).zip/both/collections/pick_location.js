this.PickLocation = new Mongo.Collection("PickLocation");

this.PickLocation.userCanInsert = function(userId, doc) {
	return true;
};

this.PickLocation.userCanUpdate = function(userId, doc) {
	return true;
};

this.PickLocation.userCanRemove = function(userId, doc) {
	return true;
};
