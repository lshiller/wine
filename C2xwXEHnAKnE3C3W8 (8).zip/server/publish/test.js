Meteor.publish("test", function(testId) {
	return Test.find({_id:testId}, {});
});

Meteor.publish("tests", function() {
	return Test.find({}, {});
});

Meteor.publish("tests_empty", function() {
	return Test.find({_id:null}, {});
});

