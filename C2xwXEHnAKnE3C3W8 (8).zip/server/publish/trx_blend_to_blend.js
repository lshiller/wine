Meteor.publish("trxblendtoblend", function(trxblendtoblendId) {
	return TrxBlendToBlend.find({_id:trxblendtoblendId}, {});
});

Meteor.publish("trxblendtoblends", function() {
	return TrxBlendToBlend.find({}, {});
});

Meteor.publish("trxblendtoblends_empty", function() {
	return TrxBlendToBlend.find({_id:null}, {});
});

