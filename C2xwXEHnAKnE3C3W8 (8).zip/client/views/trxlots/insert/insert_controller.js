this.TrxlotsInsertController = RouteController.extend({
	template: "TrxlotsInsert",
	

	yieldTemplates: {
		/*YIELD_TEMPLATES*/
	},

	onBeforeAction: function() {
		this.next();
	},

	action: function() {
		if(this.isReady()) { this.render(); } else { this.render("loading"); }
		/*ACTION_FUNCTION*/
	},

	isReady: function() {
		

		var subs = [
			Meteor.subscribe("vintages"),
			Meteor.subscribe("varietals"),
			Meteor.subscribe("picklocations"),
			Meteor.subscribe("picknumbers"),
			Meteor.subscribe("trxlots_empty")
		];
		var ready = true;
		_.each(subs, function(sub) {
			if(!sub.ready())
				ready = false;
		});
		return ready;
	},

	data: function() {
		

		var data = {
			params: this.params || {},
			vintages: Vintage.find({}, {}),
			varietals: Varietal.find({}, {}),
			picklocations: PickLocation.find({}, {}),
			picknumbers: PickNumber.find({}, {}),
			trxlots_empty: TrxLot.findOne({_id:null}, {})
		};
		

		

		return data;
	},

	onAfterAction: function() {
		
	}
});