Test.allow({
	insert: function (userId, doc) {
		return Test.userCanInsert(userId, doc);
	},

	update: function (userId, doc, fields, modifier) {
		return Test.userCanUpdate(userId, doc);
	},

	remove: function (userId, doc) {
		return Test.userCanRemove(userId, doc);
	}
});

Test.before.insert(function(userId, doc) {
	doc.createdAt = new Date();
	doc.createdBy = userId;
	doc.modifiedAt = doc.createdAt;
	doc.modifiedBy = doc.createdBy;

	
	if(!doc.createdBy) doc.createdBy = userId;
});

Test.before.update(function(userId, doc, fieldNames, modifier, options) {
	modifier.$set = modifier.$set || {};
	modifier.$set.modifiedAt = new Date();
	modifier.$set.modifiedBy = userId;

	
});

Test.before.upsert(function(userId, selector, modifier, options) {
	modifier.$set = modifier.$set || {};
	modifier.$set.modifiedAt = new Date();
	modifier.$set.modifiedBy = userId;

	/*BEFORE_UPSERT_CODE*/
});

Test.before.remove(function(userId, doc) {
	
});

Test.after.insert(function(userId, doc) {
	
});

Test.after.update(function(userId, doc, fieldNames, modifier, options) {
	
});

Test.after.remove(function(userId, doc) {
	
});
