Meteor.publish("trxtankcleaningchemical", function(trxtankcleaningchemicalId) {
	return TrxTankCleaningChemical.find({_id:trxtankcleaningchemicalId}, {});
});

Meteor.publish("trxtankcleaningchemicals", function() {
	return TrxTankCleaningChemical.find({}, {});
});

Meteor.publish("trxtankcleaningchemicals_empty", function() {
	return TrxTankCleaningChemical.find({_id:null}, {});
});

