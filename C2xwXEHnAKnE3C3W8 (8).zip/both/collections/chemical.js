this.Chemical = new Mongo.Collection("Chemical");

this.Chemical.userCanInsert = function(userId, doc) {
	return true;
};

this.Chemical.userCanUpdate = function(userId, doc) {
	return true;
};

this.Chemical.userCanRemove = function(userId, doc) {
	return true;
};
