var pageSession = new ReactiveDict();

Template.Trxfilltanks.rendered = function() {
	
};

Template.Trxfilltanks.events({
	
});

Template.Trxfilltanks.helpers({
	
});

var TrxfilltanksViewItems = function(cursor) {
	if(!cursor) {
		return [];
	}

	var searchString = pageSession.get("TrxfilltanksViewSearchString");
	var sortBy = pageSession.get("TrxfilltanksViewSortBy");
	var sortAscending = pageSession.get("TrxfilltanksViewSortAscending");
	if(typeof(sortAscending) == "undefined") sortAscending = true;

	var raw = cursor.fetch();

	// filter
	var filtered = [];
	if(!searchString || searchString == "") {
		filtered = raw;
	} else {
		searchString = searchString.replace(".", "\\.");
		var regEx = new RegExp(searchString, "i");
		var searchFields = ["Tank", "Blend", "PreFillQuantity", "MeasurementDatetime"];
		filtered = _.filter(raw, function(item) {
			var match = false;
			_.each(searchFields, function(field) {
				var value = (getPropertyValue(field, item) || "") + "";

				match = match || (value && value.match(regEx));
				if(match) {
					return false;
				}
			})
			return match;
		});
	}

	// sort
	if(sortBy) {
		filtered = _.sortBy(filtered, sortBy);

		// descending?
		if(!sortAscending) {
			filtered = filtered.reverse();
		}
	}

	return filtered;
};

var TrxfilltanksViewExport = function(cursor, fileType) {
	var data = TrxfilltanksViewItems(cursor);
	var exportFields = [];

	var str = convertArrayOfObjects(data, exportFields, fileType);

	var filename = "export." + fileType;

	downloadLocalResource(str, filename, "application/octet-stream");
}


Template.TrxfilltanksView.rendered = function() {
	pageSession.set("TrxfilltanksViewStyle", "table");
	
};

Template.TrxfilltanksView.events({
	"submit #dataview-controls": function(e, t) {
		return false;
	},

	"click #dataview-search-button": function(e, t) {
		e.preventDefault();
		var form = $(e.currentTarget).parent();
		if(form) {
			var searchInput = form.find("#dataview-search-input");
			if(searchInput) {
				searchInput.focus();
				var searchString = searchInput.val();
				pageSession.set("TrxfilltanksViewSearchString", searchString);
			}

		}
		return false;
	},

	"keydown #dataview-search-input": function(e, t) {
		if(e.which === 13)
		{
			e.preventDefault();
			var form = $(e.currentTarget).parent();
			if(form) {
				var searchInput = form.find("#dataview-search-input");
				if(searchInput) {
					var searchString = searchInput.val();
					pageSession.set("TrxfilltanksViewSearchString", searchString);
				}

			}
			return false;
		}

		if(e.which === 27)
		{
			e.preventDefault();
			var form = $(e.currentTarget).parent();
			if(form) {
				var searchInput = form.find("#dataview-search-input");
				if(searchInput) {
					searchInput.val("");
					pageSession.set("TrxfilltanksViewSearchString", "");
				}

			}
			return false;
		}

		return true;
	},

	"click #dataview-insert-button": function(e, t) {
		e.preventDefault();
		Router.go("trxfilltanks.insert", {});
	},

	"click #dataview-export-default": function(e, t) {
		e.preventDefault();
		TrxfilltanksViewExport(this.trxfilltanks, "csv");
	},

	"click #dataview-export-csv": function(e, t) {
		e.preventDefault();
		TrxfilltanksViewExport(this.trxfilltanks, "csv");
	},

	"click #dataview-export-tsv": function(e, t) {
		e.preventDefault();
		TrxfilltanksViewExport(this.trxfilltanks, "tsv");
	},

	"click #dataview-export-json": function(e, t) {
		e.preventDefault();
		TrxfilltanksViewExport(this.trxfilltanks, "json");
	}

	
});

Template.TrxfilltanksView.helpers({

	"insertButtonClass": function() {
		return TrxFillTank.userCanInsert(Meteor.userId(), {}) ? "" : "hidden";
	},

	"isEmpty": function() {
		return !this.trxfilltanks || this.trxfilltanks.count() == 0;
	},
	"isNotEmpty": function() {
		return this.trxfilltanks && this.trxfilltanks.count() > 0;
	},
	"isNotFound": function() {
		return this.trxfilltanks && pageSession.get("TrxfilltanksViewSearchString") && TrxfilltanksViewItems(this.trxfilltanks).length == 0;
	},
	"searchString": function() {
		return pageSession.get("TrxfilltanksViewSearchString");
	},
	"viewAsTable": function() {
		return pageSession.get("TrxfilltanksViewStyle") == "table";
	},
	"viewAsList": function() {
		return pageSession.get("TrxfilltanksViewStyle") == "list";
	},
	"viewAsGallery": function() {
		return pageSession.get("TrxfilltanksViewStyle") == "gallery";
	}

	
});


Template.TrxfilltanksViewTable.rendered = function() {
	
};

Template.TrxfilltanksViewTable.events({
	"click .th-sortable": function(e, t) {
		e.preventDefault();
		var oldSortBy = pageSession.get("TrxfilltanksViewSortBy");
		var newSortBy = $(e.target).attr("data-sort");

		pageSession.set("TrxfilltanksViewSortBy", newSortBy);
		if(oldSortBy == newSortBy) {
			var sortAscending = pageSession.get("TrxfilltanksViewSortAscending") || false;
			pageSession.set("TrxfilltanksViewSortAscending", !sortAscending);
		} else {
			pageSession.set("TrxfilltanksViewSortAscending", true);
		}
	}
});

Template.TrxfilltanksViewTable.helpers({
	"tableItems": function() {
		return TrxfilltanksViewItems(this.trxfilltanks);
	}
});


Template.TrxfilltanksViewTableItems.rendered = function() {
	
};

Template.TrxfilltanksViewTableItems.events({
	"click td": function(e, t) {
		e.preventDefault();
		
		Router.go("trxfilltanks.details", {trxfilltankId: this._id});
		return false;
	},

	"click .inline-checkbox": function(e, t) {
		e.preventDefault();

		if(!this || !this._id) return false;

		var fieldName = $(e.currentTarget).attr("data-field");
		if(!fieldName) return false;

		var values = {};
		values[fieldName] = !this[fieldName];

		TrxFillTank.update({ _id: this._id }, { $set: values });

		return false;
	},

	"click #delete-button": function(e, t) {
		e.preventDefault();
		var me = this;
		bootbox.dialog({
			message: "Delete? Are you sure?",
			title: "Delete",
			animate: false,
			buttons: {
				success: {
					label: "Yes",
					className: "btn-success",
					callback: function() {
						TrxFillTank.remove({ _id: me._id });
					}
				},
				danger: {
					label: "No",
					className: "btn-default"
				}
			}
		});
		return false;
	},
	"click #edit-button": function(e, t) {
		e.preventDefault();
		Router.go("trxfilltanks.edit", {trxfilltankId: this._id});
		return false;
	}
});

Template.TrxfilltanksViewTableItems.helpers({
	"checked": function(value) { return value ? "checked" : "" }, 
	"editButtonClass": function() {
		return TrxFillTank.userCanUpdate(Meteor.userId(), this) ? "" : "hidden";
	},

	"deleteButtonClass": function() {
		return TrxFillTank.userCanRemove(Meteor.userId(), this) ? "" : "hidden";
	}
});
