var pageSession = new ReactiveDict();

Template.BarrelsDetails.rendered = function() {
	
};

Template.BarrelsDetails.events({
	
});

Template.BarrelsDetails.helpers({
	
});

Template.BarrelsDetailsDetailsForm.rendered = function() {
	

	pageSession.set("barrelsDetailsDetailsFormInfoMessage", "");
	pageSession.set("barrelsDetailsDetailsFormErrorMessage", "");

	$(".input-group.date").each(function() {
		var format = $(this).find("input[type='text']").attr("data-format");

		if(format) {
			format = format.toLowerCase();
		}
		else {
			format = "mm/dd/yyyy";
		}

		$(this).datepicker({
			autoclose: true,
			todayHighlight: true,
			todayBtn: true,
			forceParse: false,
			keyboardNavigation: false,
			format: format
		});
	});

	$("input[type='file']").fileinput();
	$("select[data-role='tagsinput']").tagsinput();
	$(".bootstrap-tagsinput").addClass("form-control");
	$("input[autofocus]").focus();
};

Template.BarrelsDetailsDetailsForm.events({
	"submit": function(e, t) {
		e.preventDefault();
		pageSession.set("barrelsDetailsDetailsFormInfoMessage", "");
		pageSession.set("barrelsDetailsDetailsFormErrorMessage", "");

		var self = this;

		function submitAction(msg) {
			var barrelsDetailsDetailsFormMode = "read_only";
			if(!t.find("#form-cancel-button")) {
				switch(barrelsDetailsDetailsFormMode) {
					case "insert": {
						$(e.target)[0].reset();
					}; break;

					case "update": {
						var message = msg || "Saved.";
						pageSession.set("barrelsDetailsDetailsFormInfoMessage", message);
					}; break;
				}
			}

			/*SUBMIT_REDIRECT*/
		}

		function errorAction(msg) {
			msg = msg || "";
			var message = msg.message || msg || "Error.";
			pageSession.set("barrelsDetailsDetailsFormErrorMessage", message);
		}

		validateForm(
			$(e.target),
			function(fieldName, fieldValue) {

			},
			function(msg) {

			},
			function(values) {
				

				
			}
		);

		return false;
	},
	"click #form-cancel-button": function(e, t) {
		e.preventDefault();

		

		/*CANCEL_REDIRECT*/
	},
	"click #form-close-button": function(e, t) {
		e.preventDefault();

		Router.go("barrels", {});
	},
	"click #form-back-button": function(e, t) {
		e.preventDefault();

		Router.go("barrels", {});
	}

	
});

Template.BarrelsDetailsDetailsForm.helpers({
	"infoMessage": function() {
		return pageSession.get("barrelsDetailsDetailsFormInfoMessage");
	},
	"errorMessage": function() {
		return pageSession.get("barrelsDetailsDetailsFormErrorMessage");
	}
	
});
