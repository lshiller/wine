Meteor.publish("trxtanktest", function(trxtanktestId) {
	return TrxTankTest.find({_id:trxtanktestId}, {});
});

Meteor.publish("trxtanktests", function() {
	return TrxTankTest.find({}, {});
});

Meteor.publish("trxtanktests_empty", function() {
	return TrxTankTest.find({_id:null}, {});
});

