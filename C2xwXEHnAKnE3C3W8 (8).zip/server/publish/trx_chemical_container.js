Meteor.publish("trxchemicalconainer", function(trxchemicalconainerId) {
	return TrxChemicalContainer.find({_id:trxchemicalconainerId}, {});
});

Meteor.publish("trxchemicalconainers", function() {
	return TrxChemicalContainer.find({}, {});
});

Meteor.publish("trxchemicalconainers_empty", function() {
	return TrxChemicalContainer.find({_id:null}, {});
});

