this.TrxLot = new Mongo.Collection("TrxLot");

this.TrxLot.userCanInsert = function(userId, doc) {
	return true;
};

this.TrxLot.userCanUpdate = function(userId, doc) {
	return true;
};

this.TrxLot.userCanRemove = function(userId, doc) {
	return true;
};
