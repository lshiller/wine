Meteor.publish("picknumber", function(picknumberId) {
	return PickNumber.find({_id:picknumberId}, {});
});

Meteor.publish("picknumbers", function() {
	return PickNumber.find({}, {});
});

Meteor.publish("picknumbers_empty", function() {
	return PickNumber.find({_id:null}, {});
});

