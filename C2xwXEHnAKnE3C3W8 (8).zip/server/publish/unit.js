Meteor.publish("unit", function(unitId) {
	return Unit.find({_id:unitId}, {});
});

Meteor.publish("units", function() {
	return Unit.find({}, {});
});

Meteor.publish("units_empty", function() {
	return Unit.find({_id:null}, {});
});

