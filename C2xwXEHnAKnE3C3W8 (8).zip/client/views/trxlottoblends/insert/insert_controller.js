this.TrxlottoblendsInsertController = RouteController.extend({
	template: "TrxlottoblendsInsert",
	

	yieldTemplates: {
		/*YIELD_TEMPLATES*/
	},

	onBeforeAction: function() {
		this.next();
	},

	action: function() {
		if(this.isReady()) { this.render(); } else { this.render("loading"); }
		/*ACTION_FUNCTION*/
	},

	isReady: function() {
		

		var subs = [
			Meteor.subscribe("trxlots"),
			Meteor.subscribe("blends"),
			Meteor.subscribe("trxlottoblends_empty")
		];
		var ready = true;
		_.each(subs, function(sub) {
			if(!sub.ready())
				ready = false;
		});
		return ready;
	},

	data: function() {
		

		var data = {
			params: this.params || {},
			trxlots: TrxLot.find({}, {}),
			blends: Blend.find({}, {}),
			trxlottoblends_empty: TrxLotToBlend.findOne({_id:null}, {})
		};
		

		

		return data;
	},

	onAfterAction: function() {
		
	}
});