this.Barrel = new Mongo.Collection("Barrel");

this.Barrel.userCanInsert = function(userId, doc) {
	return true;
};

this.Barrel.userCanUpdate = function(userId, doc) {
	return true;
};

this.Barrel.userCanRemove = function(userId, doc) {
	return true;
};
