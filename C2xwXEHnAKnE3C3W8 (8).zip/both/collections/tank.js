this.Tank = new Mongo.Collection("Tank");

this.Tank.userCanInsert = function(userId, doc) {
	return true;
};

this.Tank.userCanUpdate = function(userId, doc) {
	return true;
};

this.Tank.userCanRemove = function(userId, doc) {
	return true;
};
