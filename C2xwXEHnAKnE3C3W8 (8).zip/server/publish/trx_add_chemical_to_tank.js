Meteor.publish("trxaddchemicaltotank", function(trxaddchemicaltotankId) {
	return TrxAddChemicalToTank.find({_id:trxaddchemicaltotankId}, {});
});

Meteor.publish("trxaddchemicaltotanks", function() {
	return TrxAddChemicalToTank.find({}, {});
});

Meteor.publish("trxaddchemicaltotanks_empty", function() {
	return TrxAddChemicalToTank.find({_id:null}, {});
});

