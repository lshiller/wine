var pageSession = new ReactiveDict();

Template.Chemicals.rendered = function() {
	
};

Template.Chemicals.events({
	
});

Template.Chemicals.helpers({
	
});

var ChemicalsViewItems = function(cursor) {
	if(!cursor) {
		return [];
	}

	var searchString = pageSession.get("ChemicalsViewSearchString");
	var sortBy = pageSession.get("ChemicalsViewSortBy");
	var sortAscending = pageSession.get("ChemicalsViewSortAscending");
	if(typeof(sortAscending) == "undefined") sortAscending = true;

	var raw = cursor.fetch();

	// filter
	var filtered = [];
	if(!searchString || searchString == "") {
		filtered = raw;
	} else {
		searchString = searchString.replace(".", "\\.");
		var regEx = new RegExp(searchString, "i");
		var searchFields = ["ChemicalName", "Note", "Description", "IsCleaningAgent", "IsWineAddition", "IsLabTest"];
		filtered = _.filter(raw, function(item) {
			var match = false;
			_.each(searchFields, function(field) {
				var value = (getPropertyValue(field, item) || "") + "";

				match = match || (value && value.match(regEx));
				if(match) {
					return false;
				}
			})
			return match;
		});
	}

	// sort
	if(sortBy) {
		filtered = _.sortBy(filtered, sortBy);

		// descending?
		if(!sortAscending) {
			filtered = filtered.reverse();
		}
	}

	return filtered;
};

var ChemicalsViewExport = function(cursor, fileType) {
	var data = ChemicalsViewItems(cursor);
	var exportFields = ["ChemicalName", "Note"];

	var str = convertArrayOfObjects(data, exportFields, fileType);

	var filename = "export." + fileType;

	downloadLocalResource(str, filename, "application/octet-stream");
}


Template.ChemicalsView.rendered = function() {
	pageSession.set("ChemicalsViewStyle", "table");
	
};

Template.ChemicalsView.events({
	"submit #dataview-controls": function(e, t) {
		return false;
	},

	"click #dataview-search-button": function(e, t) {
		e.preventDefault();
		var form = $(e.currentTarget).parent();
		if(form) {
			var searchInput = form.find("#dataview-search-input");
			if(searchInput) {
				searchInput.focus();
				var searchString = searchInput.val();
				pageSession.set("ChemicalsViewSearchString", searchString);
			}

		}
		return false;
	},

	"keydown #dataview-search-input": function(e, t) {
		if(e.which === 13)
		{
			e.preventDefault();
			var form = $(e.currentTarget).parent();
			if(form) {
				var searchInput = form.find("#dataview-search-input");
				if(searchInput) {
					var searchString = searchInput.val();
					pageSession.set("ChemicalsViewSearchString", searchString);
				}

			}
			return false;
		}

		if(e.which === 27)
		{
			e.preventDefault();
			var form = $(e.currentTarget).parent();
			if(form) {
				var searchInput = form.find("#dataview-search-input");
				if(searchInput) {
					searchInput.val("");
					pageSession.set("ChemicalsViewSearchString", "");
				}

			}
			return false;
		}

		return true;
	},

	"click #dataview-insert-button": function(e, t) {
		e.preventDefault();
		Router.go("chemicals.insert", {});
	},

	"click #dataview-export-default": function(e, t) {
		e.preventDefault();
		ChemicalsViewExport(this.chemicals, "csv");
	},

	"click #dataview-export-csv": function(e, t) {
		e.preventDefault();
		ChemicalsViewExport(this.chemicals, "csv");
	},

	"click #dataview-export-tsv": function(e, t) {
		e.preventDefault();
		ChemicalsViewExport(this.chemicals, "tsv");
	},

	"click #dataview-export-json": function(e, t) {
		e.preventDefault();
		ChemicalsViewExport(this.chemicals, "json");
	}

	
});

Template.ChemicalsView.helpers({

	"insertButtonClass": function() {
		return Chemical.userCanInsert(Meteor.userId(), {}) ? "" : "hidden";
	},

	"isEmpty": function() {
		return !this.chemicals || this.chemicals.count() == 0;
	},
	"isNotEmpty": function() {
		return this.chemicals && this.chemicals.count() > 0;
	},
	"isNotFound": function() {
		return this.chemicals && pageSession.get("ChemicalsViewSearchString") && ChemicalsViewItems(this.chemicals).length == 0;
	},
	"searchString": function() {
		return pageSession.get("ChemicalsViewSearchString");
	},
	"viewAsTable": function() {
		return pageSession.get("ChemicalsViewStyle") == "table";
	},
	"viewAsList": function() {
		return pageSession.get("ChemicalsViewStyle") == "list";
	},
	"viewAsGallery": function() {
		return pageSession.get("ChemicalsViewStyle") == "gallery";
	}

	
});


Template.ChemicalsViewTable.rendered = function() {
	
};

Template.ChemicalsViewTable.events({
	"click .th-sortable": function(e, t) {
		e.preventDefault();
		var oldSortBy = pageSession.get("ChemicalsViewSortBy");
		var newSortBy = $(e.target).attr("data-sort");

		pageSession.set("ChemicalsViewSortBy", newSortBy);
		if(oldSortBy == newSortBy) {
			var sortAscending = pageSession.get("ChemicalsViewSortAscending") || false;
			pageSession.set("ChemicalsViewSortAscending", !sortAscending);
		} else {
			pageSession.set("ChemicalsViewSortAscending", true);
		}
	}
});

Template.ChemicalsViewTable.helpers({
	"tableItems": function() {
		return ChemicalsViewItems(this.chemicals);
	}
});


Template.ChemicalsViewTableItems.rendered = function() {
	
};

Template.ChemicalsViewTableItems.events({
	"click td": function(e, t) {
		e.preventDefault();
		
		Router.go("chemicals.details", {chemicalId: this._id});
		return false;
	},

	"click .inline-checkbox": function(e, t) {
		e.preventDefault();

		if(!this || !this._id) return false;

		var fieldName = $(e.currentTarget).attr("data-field");
		if(!fieldName) return false;

		var values = {};
		values[fieldName] = !this[fieldName];

		Chemical.update({ _id: this._id }, { $set: values });

		return false;
	},

	"click #delete-button": function(e, t) {
		e.preventDefault();
		var me = this;
		bootbox.dialog({
			message: "Delete? Are you sure?",
			title: "Delete",
			animate: false,
			buttons: {
				success: {
					label: "Yes",
					className: "btn-success",
					callback: function() {
						Chemical.remove({ _id: me._id });
					}
				},
				danger: {
					label: "No",
					className: "btn-default"
				}
			}
		});
		return false;
	},
	"click #edit-button": function(e, t) {
		e.preventDefault();
		Router.go("chemicals.edit", {chemicalId: this._id});
		return false;
	}
});

Template.ChemicalsViewTableItems.helpers({
	"checked": function(value) { return value ? "checked" : "" }, 
	"editButtonClass": function() {
		return Chemical.userCanUpdate(Meteor.userId(), this) ? "" : "hidden";
	},

	"deleteButtonClass": function() {
		return Chemical.userCanRemove(Meteor.userId(), this) ? "" : "hidden";
	}
});
