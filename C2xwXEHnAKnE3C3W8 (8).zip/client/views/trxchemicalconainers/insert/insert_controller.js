this.TrxchemicalconainersInsertController = RouteController.extend({
	template: "TrxchemicalconainersInsert",
	

	yieldTemplates: {
		/*YIELD_TEMPLATES*/
	},

	onBeforeAction: function() {
		this.next();
	},

	action: function() {
		if(this.isReady()) { this.render(); } else { this.render("loading"); }
		/*ACTION_FUNCTION*/
	},

	isReady: function() {
		

		var subs = [
			Meteor.subscribe("chemicalmanufacturers"),
			Meteor.subscribe("chemicals"),
			Meteor.subscribe("units"),
			Meteor.subscribe("trxchemicalconainers_empty")
		];
		var ready = true;
		_.each(subs, function(sub) {
			if(!sub.ready())
				ready = false;
		});
		return ready;
	},

	data: function() {
		

		var data = {
			params: this.params || {},
			chemicalmanufacturers: ChemicalManufacturer.find({}, {}),
			chemicals: Chemical.find({}, {}),
			units: Unit.find({}, {}),
			trxchemicalconainers_empty: TrxChemicalContainer.findOne({_id:null}, {})
		};
		

		

		return data;
	},

	onAfterAction: function() {
		
	}
});