TrxLot.allow({
	insert: function (userId, doc) {
		return TrxLot.userCanInsert(userId, doc);
	},

	update: function (userId, doc, fields, modifier) {
		return TrxLot.userCanUpdate(userId, doc);
	},

	remove: function (userId, doc) {
		return TrxLot.userCanRemove(userId, doc);
	}
});

TrxLot.before.insert(function(userId, doc) {
	doc.createdAt = new Date();
	doc.createdBy = userId;
	doc.modifiedAt = doc.createdAt;
	doc.modifiedBy = doc.createdBy;

	
	if(!doc.createdBy) doc.createdBy = userId;
});

TrxLot.before.update(function(userId, doc, fieldNames, modifier, options) {
	modifier.$set = modifier.$set || {};
	modifier.$set.modifiedAt = new Date();
	modifier.$set.modifiedBy = userId;

	
});

TrxLot.before.upsert(function(userId, selector, modifier, options) {
	modifier.$set = modifier.$set || {};
	modifier.$set.modifiedAt = new Date();
	modifier.$set.modifiedBy = userId;

	/*BEFORE_UPSERT_CODE*/
});

TrxLot.before.remove(function(userId, doc) {
	
});

TrxLot.after.insert(function(userId, doc) {
	
});

TrxLot.after.update(function(userId, doc, fieldNames, modifier, options) {
	
});

TrxLot.after.remove(function(userId, doc) {
	
});
