Meteor.publish("chemical", function(chemicalId) {
	return Chemical.find({_id:chemicalId}, {});
});

Meteor.publish("chemicals", function() {
	return Chemical.find({}, {});
});

Meteor.publish("chemicals_empty", function() {
	return Chemical.find({_id:null}, {});
});

