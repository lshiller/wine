Meteor.publish("press", function(pressId) {
	return Press.find({_id:pressId}, {});
});

Meteor.publish("presss", function() {
	return Press.find({}, {});
});

Meteor.publish("presss_empty", function() {
	return Press.find({_id:null}, {});
});

